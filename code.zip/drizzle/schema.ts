import {
  char,
  foreignKey,
  index,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

/** Existing template table retained for compatibility; the product uses its own username/password accounts below. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const gigiUsers = mysqlTable(
  "gigi_users",
  {
    id: int("id").autoincrement().primaryKey(),
    username: varchar("username", { length: 24 }).notNull(),
    passwordHash: varchar("passwordHash", { length: 255 }).notNull(),
    avatarUrl: varchar("avatarUrl", { length: 512 }),
    bio: varchar("bio", { length: 280 }).default("").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [uniqueIndex("gigi_users_username_uq").on(table.username)],
);

export const gigiSessions = mysqlTable(
  "gigi_sessions",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    tokenHash: char("tokenHash", { length: 64 }).notNull(),
    expiresAt: timestamp("expiresAt").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [
    uniqueIndex("gigi_sessions_token_uq").on(table.tokenHash),
    index("gigi_sessions_user_idx").on(table.userId),
    index("gigi_sessions_expiry_idx").on(table.expiresAt),
    foreignKey({ columns: [table.userId], foreignColumns: [gigiUsers.id], name: "gigi_sessions_user_fk" }).onDelete("cascade"),
  ],
);

export const gigiPosts = mysqlTable(
  "gigi_posts",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    caption: varchar("caption", { length: 500 }).default("").notNull(),
    imageUrl: varchar("imageUrl", { length: 512 }).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    deletedAt: timestamp("deletedAt"),
  },
  table => [
    index("gigi_posts_created_idx").on(table.createdAt, table.id),
    index("gigi_posts_user_idx").on(table.userId, table.id),
    foreignKey({ columns: [table.userId], foreignColumns: [gigiUsers.id], name: "gigi_posts_user_fk" }).onDelete("cascade"),
  ],
);

export const gigiLikes = mysqlTable(
  "gigi_likes",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    postId: int("postId").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [
    uniqueIndex("gigi_likes_user_post_uq").on(table.userId, table.postId),
    index("gigi_likes_post_idx").on(table.postId),
    foreignKey({ columns: [table.userId], foreignColumns: [gigiUsers.id], name: "gigi_likes_user_fk" }).onDelete("cascade"),
    foreignKey({ columns: [table.postId], foreignColumns: [gigiPosts.id], name: "gigi_likes_post_fk" }).onDelete("cascade"),
  ],
);

export const gigiComments = mysqlTable(
  "gigi_comments",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    postId: int("postId").notNull(),
    content: varchar("content", { length: 500 }).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    deletedAt: timestamp("deletedAt"),
  },
  table => [
    index("gigi_comments_post_created_idx").on(table.postId, table.createdAt),
    index("gigi_comments_user_idx").on(table.userId),
    foreignKey({ columns: [table.userId], foreignColumns: [gigiUsers.id], name: "gigi_comments_user_fk" }).onDelete("cascade"),
    foreignKey({ columns: [table.postId], foreignColumns: [gigiPosts.id], name: "gigi_comments_post_fk" }).onDelete("cascade"),
  ],
);
