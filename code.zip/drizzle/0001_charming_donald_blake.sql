CREATE TABLE `gigi_comments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`postId` int NOT NULL,
	`content` varchar(500) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`deletedAt` timestamp,
	CONSTRAINT `gigi_comments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `gigi_likes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`postId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `gigi_likes_id` PRIMARY KEY(`id`),
	CONSTRAINT `gigi_likes_user_post_uq` UNIQUE(`userId`,`postId`)
);
--> statement-breakpoint
CREATE TABLE `gigi_posts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`caption` varchar(500) NOT NULL DEFAULT '',
	`imageUrl` varchar(512) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`deletedAt` timestamp,
	CONSTRAINT `gigi_posts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `gigi_sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`tokenHash` char(64) NOT NULL,
	`expiresAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `gigi_sessions_id` PRIMARY KEY(`id`),
	CONSTRAINT `gigi_sessions_token_uq` UNIQUE(`tokenHash`)
);
--> statement-breakpoint
CREATE TABLE `gigi_users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`username` varchar(24) NOT NULL,
	`passwordHash` varchar(255) NOT NULL,
	`avatarUrl` varchar(512),
	`bio` varchar(280) NOT NULL DEFAULT '',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `gigi_users_id` PRIMARY KEY(`id`),
	CONSTRAINT `gigi_users_username_uq` UNIQUE(`username`)
);
--> statement-breakpoint
ALTER TABLE `gigi_comments` ADD CONSTRAINT `gigi_comments_user_fk` FOREIGN KEY (`userId`) REFERENCES `gigi_users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `gigi_comments` ADD CONSTRAINT `gigi_comments_post_fk` FOREIGN KEY (`postId`) REFERENCES `gigi_posts`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `gigi_likes` ADD CONSTRAINT `gigi_likes_user_fk` FOREIGN KEY (`userId`) REFERENCES `gigi_users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `gigi_likes` ADD CONSTRAINT `gigi_likes_post_fk` FOREIGN KEY (`postId`) REFERENCES `gigi_posts`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `gigi_posts` ADD CONSTRAINT `gigi_posts_user_fk` FOREIGN KEY (`userId`) REFERENCES `gigi_users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `gigi_sessions` ADD CONSTRAINT `gigi_sessions_user_fk` FOREIGN KEY (`userId`) REFERENCES `gigi_users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `gigi_comments_post_created_idx` ON `gigi_comments` (`postId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `gigi_comments_user_idx` ON `gigi_comments` (`userId`);--> statement-breakpoint
CREATE INDEX `gigi_likes_post_idx` ON `gigi_likes` (`postId`);--> statement-breakpoint
CREATE INDEX `gigi_posts_created_idx` ON `gigi_posts` (`createdAt`,`id`);--> statement-breakpoint
CREATE INDEX `gigi_posts_user_idx` ON `gigi_posts` (`userId`,`id`);--> statement-breakpoint
CREATE INDEX `gigi_sessions_user_idx` ON `gigi_sessions` (`userId`);--> statement-breakpoint
CREATE INDEX `gigi_sessions_expiry_idx` ON `gigi_sessions` (`expiresAt`);