# GIGI — Official Site & Community Feed

React / Express / tRPC / Drizzle website built from the Manus `web-db-user` template.

- `pnpm dev`: development server; honors `PORT` (default 3000).
- `pnpm build` / `pnpm start`: build and serve `dist/index.js` and `dist/public/`.
- `pnpm db:migrate`: apply checked-in migrations. `pnpm db:push`: generate and apply new schema changes.
- `pnpm check` / `pnpm test`: types and application tests.

Start with the Webdev skill's default-template guide. Platform login, storage and service contracts live in its shared references; read the relevant capability before extending a helper.

`server/_core/publicConfig.ts` exposes only named public runtime values. Private keys stay server-side. The platform serves managed `/manus-storage/` assets; the application does not register a second proxy.

Platform configuration is readable and editable through `webdev.config`. Default settings are initial values, not enforced constraints. The agent may modify the files, commands and configuration or follow the flexible guide for another stack.

## GIGI application

The official brand/story site is `/`; the separate public community meme Feed is `/feed`. The `/about` permalink is retained, with `/post/new`, `/profile/:username` and `/meme/:id` for the existing community product. `client/src/pages/Home.tsx` composes the official story sections, `client/src/pages/Feed.tsx` contains the database-backed feed, and `client/src/components/gigi/MarketingSections.tsx` holds the GIGI hero, About, token, community, roadmap and live-feed preview. `SiteShell.tsx` provides route-aware main-site and Feed navigation. The user-supplied Chihuahua logo/photo and generated cosmic mountain visual are used as supporting imagery; cosmic styling is a visual design language, not project narrative.

`server/routers.ts` implements the account, profile, feed, post, like and comment procedures. `server/auth.ts` provides the application session layer; `server/_core/index.ts` contains the size- and signature-checked upload route. `drizzle/schema.ts` and `drizzle/0001_charming_donald_blake.sql` define the persistent application schema; this route/content restructure adds no migration.

This project uses the Manus-managed MySQL-compatible database and managed object storage, not Supabase/PostgreSQL. No Supabase configuration or credentials are connected or required. The platform supplies `DATABASE_URL`, `MANUS_API_URL` and `MANUS_API_KEY` to the server runtime; private values are not included in browser code. MySQL does not support PostgreSQL RLS, so protected operations enforce authorization and account/post/comment ownership server-side.

Passwords use salted Node scrypt hashes. The app stores random session tokens only as SHA-256 digests in the `gigi_sessions` table, in addition to an HTTP-only application cookie. Application rate limits are process-local and therefore reset if the service restarts; they are not a distributed quota. Deleting a meme hides its row from the application, but the platform storage API does not provide an object-delete action, so the stored image bytes are not claimed to be physically erased.

The dev/production database is shared; no account or social-content writes were made for this redesign validation. See [TODO.md](./TODO.md) for the complete approved acceptance criteria and current status.
