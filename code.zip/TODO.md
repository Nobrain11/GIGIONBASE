# GIGI official site + Feed — approved outcomes

## 1. Brand identity, shell and navigation
- [x] GIGI is presented as “GIGI — A MEME TOKEN ON BASE”, dedicated to the cutest and sweetest Chihuahua Gigi Marie. Use the supplied project narrative: “GIGI is a meme token on Base network dedicated to the cutest and sweetest Chihuahua Gigi Marie. We’re building something different and unique, stick around for the long ride.” GIGI is not a blanket-themed website; a blanket is only part of Gigi’s imagery, not the project topic or narrative.
- [x] Use a premium Base-inspired visual identity: dominant Base blue, deep blue/navy depth, white typography, light-blue accents, subtle gradients, modern glass/translucent surfaces, rounded cards, smooth animations, bold typography and playful crypto-native details. Feel crypto-native + internet culture + memes + Base. Avoid blanket/bedroom, terminal/hacker, generic crypto dashboard or corporate-finance aesthetics. The Chihuahua Gigi Marie is the mascot and emotional identity.
- [x] Main-site navigation shows HOME, ABOUT, TOKEN, COMMUNITY, ROADMAP and FEED. The first five navigate through the main long-scrolling website; FEED opens the separate GIGI meme social experience. Navigation is clean and responsive.
- [ ] Keep GIGI branding, Base-blue identity, typography and visual language connected across the main site and Feed, while the Feed retains its own focused social interface. Preserve username/password authentication, profile, post, like, comment, upload, public-post and deletion behavior already present.

## 2. Brand-first hero and landing page
- [x] The first view is visually powerful and immediately establishes GIGI’s identity, with a large GIGI logo, strong Base-blue environment, authentic Gigi Marie imagery when provided, premium subtle animation, clean typography and strong crypto meme identity.
- [x] Display “GIGI” and “THE CUTEST MEME ON BASE.”, followed by “GIGI is a meme token on Base network dedicated to the cutest and sweetest Chihuahua Gigi Marie.” and “We’re building something different and unique. Stick around for the long ride.”
- [x] Provide EXPLORE GIGI, which scrolls through the main site, and ENTER THE FEED, which opens the separate social meme feed. Keep the hero memorable without crowding it.
- [x] The Feed is not the first thing visitors see at `/`; `/` first introduces and establishes the GIGI brand and project narrative.

## 3. Main-site story, token, community and roadmap
- [x] ABOUT GIGI is a strong storytelling section with headline “MEET GIGI 🐶”. Explain “GIGI is a meme token on Base dedicated to Gigi Marie, the cutest and sweetest Chihuahua.” and “The project is building something different and unique around memes, crypto culture, community, and creativity.” Use large visual storytelling elements and tasteful scroll animations. Do not invent facts/history. Keep the messaging focused on GIGI + BASE + MEME CULTURE + COMMUNITY.
- [x] TOKEN section headline is “$GIGI ON BASE” and displays Token: GIGI; Ticker: $GIGI; Network: Base; Contract Address: 0x0a39d88c49d47c111bed9fa7e9b988b8686f3222. Provide a working COPY CONTRACT button. Add DexScreener, X, Telegram or other links only when official verified URLs are available. Do not invent prices, market caps, liquidity, volume, holder counts or trading statistics; make no financial promises. Keep the section polished and crypto-native, not a trading dashboard.
- [x] COMMUNITY section headline is “THE GIGI COMMUNITY”; supporting copy is “GIGI is more than a meme. It’s a community building something different on Base.” Include clear actions FOLLOW ON X, JOIN THE COMMUNITY and ENTER THE FEED; use official links only when supplied. Until verified X/community destinations are supplied, do not invent or route to unofficial links; make that limitation clear while keeping ENTER THE FEED functional. Make this section visually energetic and social.
- [x] ROADMAP presents the following as development goals/direction, not guaranteed promises, in a visually interesting timeline with smooth scroll animations:
  - PHASE 01 — GIGI ARRIVES: Establish the GIGI identity; Build awareness; Grow the community.
  - PHASE 02 — MEME CULTURE: Expand the community meme culture; Launch and grow the GIGI Feed; Encourage community-created content.
  - PHASE 03 — COMMUNITY GROWTH: Expand the GIGI community; Build new experiences; Continue growing across crypto culture.
  - PHASE 04 — THE LONG RIDE: Continue building; Continue creating; Let the community help shape what comes next.

## 4. Meme-culture preview and separate Feed
- [x] Before the main-site footer, include a meme-culture teaser with headline “EVERYONE MEMES.”, supporting copy “The GIGI Feed is where the community creates, shares, and discovers crypto memes.”, a preview of real meme cards or featured posts, and a strong ENTER THE GIGI FEED → CTA that opens the social Feed. Do not fabricate activity or present fake data as community posts; if there are no posts, show an honest empty teaser.
- [x] FEED navigation and ENTER THE FEED take visitors to a dedicated social meme experience, separate from the homepage, while preserving the common GIGI brand. Feed navigation includes GIGI logo, FEED, POST A MEME, PROFILE (or sign-in when logged out) and BACK TO GIGI.
- [ ] Feed is public; visitors can browse without an account. Show newest posts first. Each post displays profile picture, username, timestamp, caption, meme image, like button/count, comment button/count and share button. Public post pages remain shareable. The Feed works on desktop and especially mobile.

## 5. Accounts, profiles, posts and media
- [ ] Registration, login, logout and persistent sessions use username and password only. Do not require email, wallet connection or crypto wallet. Hash passwords securely, never store plaintext, enforce unique usernames and retain server-side validation and useful errors.
- [ ] Users can upload/change profile picture, add/edit a short bio and view their published memes. Each profile shows profile image, username, bio and published posts. Users can edit only their own profile.
- [ ] Authenticated users can upload a meme image, preview it, add a caption and publish it. The published post appears in Feed and persists after refresh. Keep V1 simple; do not add a complicated meme generator.
- [ ] Users can upload JPG, PNG or WebP only; validate file format, signature and size, use durable storage, show progress where possible and provide clear upload/success/error feedback. Users can delete only their own posts. Do not claim physical object deletion if the runtime storage API only supports hiding/deleting the application record.

## 6. Likes, comments and sharing
- [ ] Authenticated users can like/unlike; prevent duplicate likes per user/post, persist likes and show accurate counts.
- [ ] Authenticated users can read and add comments, see commenter profile picture, username, comment and timestamp, and delete only their own comments. Persist comments and counts; apply input validation and sensible anti-spam/rate limits.
- [ ] Use native browser sharing where supported and copy-link fallback otherwise; every public post has a shareable URL and clear success/failure feedback.

## 7. Persistence and security
- [ ] Persist accounts/profiles, posts, likes and comments in the configured managed database with relational ownership, indexes, uniqueness constraints, server-side validation and access policies. Persist images in durable object storage. Enable RLS if the selected database supports it; otherwise enforce equivalent authorization server-side.
- [ ] Only authenticated users create posts, likes and comments. Users may edit only their own profiles, modify/delete only their own posts and delete only their own comments. Restrict uploads by format/size and protect against unauthorized access. Never expose server credentials in frontend code.
- [ ] Use initialized managed database/server/storage only where connected and available. If required configuration is missing, state exactly what setup is needed; never claim an unconnected service is functional.

## 8. Responsive quality and metadata
- [ ] Main site and Feed remain responsive on desktop and especially mobile; navigation works, images fit, cards are readable, touch controls are usable, forms/uploading are comfortable, and there is no horizontal overflow.
- [ ] Keep the site premium, distinctive, smooth and readable. Include loading, empty, error/retry and success states, form validation and correct auth checks; every visible button performs its stated action. Respect reduced-motion preferences.
- [x] Update title, description, theme and social-preview copy to reflect GIGI as a Base meme-token project; do not invent a canonical public URL or unofficial social links.
- [ ] Keep V1 focused on GIGI’s official story and its social meme Feed. Do not add wallets, trading, charts, token dashboards, fake metrics/promises, games, daily challenges, leaderboards, points/rewards, follows/followers, complex notifications, NFT features, unrelated dashboards or an overly complicated meme editor.

## Current implementation status and constraints

Before this approved restructure, the root `/` rendered the public social feed and `/about` rendered the About/token view. The real account/feed/PostCard/backend behavior is already implemented; this approved change moves the Feed to `/feed` and makes `/` the official story site. The existing generated cosmic mountain background and supplied Chihuahua logo/photo are available and will be reused; cosmic style is visual design only, not project narrative. The configured development/production database is shared. Prior visual/read-only checks and six passing tests exist, but authenticated registration, edits, uploads and social writes have deliberately not been exercised against production-shared data. No schema migration is planned for this route/content change.

## Verification after implementation

The official root page, live meme-preview cards, public `/feed`, anchor navigation (`EXPLORE GIGI` and the Token navigation item), and contract-copy confirmation were observed in the stable Preview. The exact homepage/token/community/roadmap copy is displayed, the roadmap is identified as direction rather than a promise, and no unverified social destination or market statistic was added. Desktop, tablet and mobile renders were visually inspected through the stable managed-storage Preview proxy. `pnpm check`, all 6 unit tests, `pnpm build`, `/api/health` (200), and the `/manus-routes.json` endpoint were verified. The managed database is shared by development and production; no test registration, profile edit, upload, post, like or comment writes were made. Account/social write paths remain unverified end-to-end; see the still-open outcomes above.


The “Join the community” button was clicked in Preview after the review fix: it shows “Official community link not configured” and the verified-destination guidance instead of opening registration. The “Enter the Feed” hero CTA was also clicked and reached `/feed` without requiring login.