import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import SiteShell from "./components/gigi/SiteShell";
import AboutPage from "./pages/About";
import CreatePostPage from "./pages/CreatePost";
import FeedPage from "./pages/Feed";
import Home from "./pages/Home";
import PostPage from "./pages/Post";
import ProfilePage from "./pages/Profile";
import NotFound from "./pages/NotFound";

function AppRoutes() {
  return <SiteShell>
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/feed" component={FeedPage} />
      <Route path="/about" component={AboutPage} />
      <Route path="/post/new" component={CreatePostPage} />
      <Route path="/profile/:username">{params => <ProfilePage username={params.username} />}</Route>
      <Route path="/meme/:id">{params => <PostPage id={params.id} />}</Route>
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  </SiteShell>;
}

export default function App() {
  return <ErrorBoundary><AppRoutes /></ErrorBoundary>;
}
