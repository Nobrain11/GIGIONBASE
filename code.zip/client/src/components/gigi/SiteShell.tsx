import { createContext, useContext, useMemo, useState, type MouseEvent as ReactMouseEvent, type ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { ArrowLeft, ArrowRight, BookOpen, LogIn, LogOut, Menu, Plus, UserRound, X } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import AuthDialog from "./AuthDialog";
import { copyText, GIGI_LOGO_URL } from "./utils";
import type { inferRouterOutputs } from "@trpc/server";
import type { AppRouter } from "../../../../server/routers";

export type Account = NonNullable<inferRouterOutputs<AppRouter>["auth"]["me"]>;
type AuthDialogMode = "login" | "register";
type SiteContextValue = { user: Account | null; loading: boolean; openAuth: (mode?: AuthDialogMode) => void };
const SiteContext = createContext<SiteContextValue | null>(null);
const CONTRACT = "0x0a39d88c49d47c111bed9fa7e9b988b8686f3222";

export function useSite() {
  const value = useContext(SiteContext);
  if (!value) throw new Error("useSite must be used inside SiteShell");
  return value;
}

function isSocialRoute(path: string) {
  return path === "/feed" || path === "/post/new" || path.startsWith("/profile/") || path.startsWith("/meme/");
}

function AnchorLink({ id, children, className, onNavigate }: { id: string; children: ReactNode; className?: string; onNavigate?: () => void }) {
  const handleClick = (event: ReactMouseEvent<HTMLAnchorElement>) => {
    onNavigate?.();
    if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    if (window.location.pathname !== "/") return;
    const target = document.getElementById(id);
    if (!target) return;
    event.preventDefault();
    window.history.pushState(null, "", `/#${id}`);
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    target.scrollIntoView({ behavior: reduceMotion ? "auto" : "smooth", block: "start" });
  };
  return <a href={`/#${id}`} className={className} onClick={handleClick}>{children}</a>;
}

function BrandMark() {
  return <img className="brand-mark" src={GIGI_LOGO_URL} alt="" aria-hidden="true" />;
}

function SiteHeader({ user, onLogin, onRegister, onLogout }: { user: Account | null; onLogin: () => void; onRegister: () => void; onLogout: () => void }) {
  const [path] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const social = isSocialRoute(path);
  const closeMenu = () => setMobileOpen(false);
  const profileHref = user ? `/profile/${user.username}` : undefined;
  const marketingNav = <>
    <AnchorLink id="home" className={`nav-link ${path === "/" ? "active" : ""}`} onNavigate={closeMenu}>Home</AnchorLink>
    <AnchorLink id="about" className="nav-link" onNavigate={closeMenu}>About</AnchorLink>
    <AnchorLink id="token" className="nav-link" onNavigate={closeMenu}>Token</AnchorLink>
    <AnchorLink id="community" className="nav-link" onNavigate={closeMenu}>Community</AnchorLink>
    <AnchorLink id="roadmap" className="nav-link" onNavigate={closeMenu}>Roadmap</AnchorLink>
    <Link href="/feed" className={`nav-link nav-feed ${path === "/feed" ? "active" : ""}`} onClick={closeMenu}>Feed</Link>
  </>;
  const socialNav = <>
    <Link href="/feed" className={`nav-link ${path === "/feed" ? "active" : ""}`} onClick={closeMenu}>Feed</Link>
    <Link href="/post/new" className="nav-link nav-post" onClick={closeMenu}><Plus size={15} strokeWidth={2.5} /> Post a meme</Link>
    {user && profileHref ? <Link href={profileHref} className={`nav-link nav-account ${path.startsWith("/profile/") ? "active" : ""}`} onClick={closeMenu}><UserRound size={16} /> Profile</Link> : <button className="nav-link nav-account" onClick={() => { closeMenu(); onLogin(); }}><LogIn size={16} /> Log in</button>}
    <Link href="/" className="nav-link nav-back" onClick={closeMenu}><ArrowLeft size={14} /> Back to GIGI</Link>
  </>;

  return <header className={`site-header ${social ? "site-header-social" : "site-header-marketing"}`}>
    <div className="header-inner">
      <Link href="/" className="brand" aria-label="GIGI home" onClick={closeMenu}><BrandMark /><span className="brand-copy"><span className="brand-title">GIGI</span><span className="brand-kicker">MEME TOKEN ON BASE</span></span></Link>
      <nav className={`desktop-nav ${social ? "social-nav" : "marketing-nav"}`} aria-label="Main navigation">{social ? socialNav : marketingNav}</nav>
      {!social && <div className="header-account">{user && profileHref ? <Link href={profileHref} className="nav-link nav-account" onClick={closeMenu}><UserRound size={15} /> Profile</Link> : <button className="nav-link nav-account" onClick={onRegister}><LogIn size={15} /> Join GIGI</button>}{user && <button className="nav-link nav-logout" onClick={onLogout}><LogOut size={15} /> Log out</button>}</div>}
      <button className="mobile-menu-toggle icon-button" aria-label={mobileOpen ? "Close menu" : "Open menu"} aria-expanded={mobileOpen} onClick={() => setMobileOpen(open => !open)}>{mobileOpen ? <X size={20} /> : <Menu size={20} />}</button>
    </div>
    {mobileOpen && <nav className={`mobile-menu ${social ? "mobile-social-menu" : "mobile-marketing-menu"}`} aria-label="Mobile navigation">{social ? socialNav : <>{marketingNav}{user && <button className="nav-link nav-logout" onClick={() => { closeMenu(); onLogout(); }}><LogOut size={15} /> Log out</button>}{!user && <button className="nav-link nav-account" onClick={() => { closeMenu(); onRegister(); }}><LogIn size={15} /> Join GIGI</button>}</>}</nav>}
  </header>;
}

function SiteFooter() {
  const [copied, setCopied] = useState(false);
  const copyContract = async () => {
    try { await copyText(CONTRACT); setCopied(true); toast.success("GIGI contract copied"); window.setTimeout(() => setCopied(false), 1800); }
    catch { toast.error("Couldn’t copy the contract address"); }
  };
  return <footer className="site-footer">
    <div className="footer-brand"><BrandMark /><div><strong>GIGI</strong><span>Meme token on Base</span></div></div>
    <div className="footer-copy"><span className="footer-contract-label">CONTRACT</span><code>{CONTRACT}</code><button className="text-button" onClick={copyContract}>{copied ? "Copied" : "Copy contract"}</button></div>
    <div className="footer-links"><a href="/#about"><BookOpen size={15} /> About GIGI</a><Link href="/feed"><ArrowRight size={15} /> Community Feed</Link><span className="footer-muted">Official social links only when verified.</span></div>
    <p className="footer-slogan">THE CUTEST MEME ON BASE</p>
  </footer>;
}

function MobileQuickNav({ path, user, onLogin, onRegister }: { path: string; user: Account | null; onLogin: () => void; onRegister: () => void }) {
  const social = isSocialRoute(path);
  const profileHref = user ? `/profile/${user.username}` : undefined;
  if (social) return <nav className="mobile-bottom-nav social-bottom-nav" aria-label="Feed quick navigation">
    <Link href="/feed" className={path === "/feed" ? "selected" : ""}><span className="bottom-nav-mark">≋</span><span>Feed</span></Link>
    <Link href="/post/new" className="bottom-post"><Plus size={19} /><span>Post</span></Link>
    {user && profileHref ? <Link href={profileHref} className={path.startsWith("/profile/") ? "selected" : ""}><UserRound size={18} /><span>Profile</span></Link> : <button onClick={onLogin}><LogIn size={18} /><span>Log in</span></button>}
    <Link href="/"><ArrowLeft size={18} /><span>Back</span></Link>
  </nav>;
  return <nav className="mobile-bottom-nav marketing-bottom-nav" aria-label="GIGI quick navigation">
    <AnchorLink id="home"><span className="bottom-nav-mark">⌂</span><span>Home</span></AnchorLink>
    <AnchorLink id="about"><BookOpen size={18} /><span>About</span></AnchorLink>
    <Link href="/feed"><span className="bottom-nav-mark">≋</span><span>Feed</span></Link>
    {user && profileHref ? <Link href={profileHref}><UserRound size={18} /><span>Profile</span></Link> : <button onClick={onRegister}><LogIn size={18} /><span>Join</span></button>}
  </nav>;
}

export default function SiteShell({ children }: { children: ReactNode }) {
  const [dialogMode, setDialogMode] = useState<AuthDialogMode | null>(null);
  const [path] = useLocation();
  const auth = trpc.auth.me.useQuery(undefined, { staleTime: 30_000, retry: 1 });
  const utils = trpc.useUtils();
  const logout = trpc.auth.logout.useMutation({
    onSuccess: async () => { await utils.auth.me.invalidate(); await utils.feed.invalidate(); toast.success("You’re signed out. See you in the Feed."); },
    onError: error => toast.error(error.message || "Couldn’t sign out."),
  });
  const value = useMemo<SiteContextValue>(() => ({ user: auth.data ?? null, loading: auth.isLoading, openAuth: mode => setDialogMode(mode ?? "login") }), [auth.data, auth.isLoading]);

  return <SiteContext.Provider value={value}>
    <div className="site-frame">
      <SiteHeader user={value.user} onLogin={() => setDialogMode("login")} onRegister={() => setDialogMode("register")} onLogout={() => logout.mutate()} />
      <main className={`site-main ${path === "/" ? "site-main-landing" : ""}`} key={path}>{children}</main>
      <SiteFooter />
      <MobileQuickNav path={path} user={value.user} onLogin={() => setDialogMode("login")} onRegister={() => setDialogMode("register")} />
    </div>
    <AuthDialog mode={dialogMode} onModeChange={setDialogMode} onClose={() => setDialogMode(null)} onAuthenticated={() => { void utils.auth.me.invalidate(); void utils.feed.invalidate(); setDialogMode(null); }} />
  </SiteContext.Provider>;
}
