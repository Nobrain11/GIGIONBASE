import { useEffect, useState, type FormEvent } from "react";
import { LockKeyhole, UserRound, X } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { GIGI_LOGO_URL } from "./utils";

type Mode = "login" | "register";
export default function AuthDialog({ mode, onModeChange, onClose, onAuthenticated }: { mode: Mode | null; onModeChange: (mode: Mode) => void; onClose: () => void; onAuthenticated: () => void }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const utils = trpc.useUtils();
  const login = trpc.auth.login.useMutation();
  const register = trpc.auth.register.useMutation();
  const busy = login.isPending || register.isPending;

  useEffect(() => {
    if (!mode) return;
    setError("");
    const onKeyDown = (event: KeyboardEvent) => { if (event.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [mode, onClose]);

  if (!mode) return null;
  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setError("");
    const normalized = username.trim().toLowerCase();
    if (!/^[a-z0-9_]{3,20}$/.test(normalized)) { setError("Choose a username with 3–20 letters, numbers or underscores."); return; }
    if (password.length < 10) { setError("Your password needs at least 10 characters."); return; }
    try {
      if (mode === "register") await register.mutateAsync({ username: normalized, password });
      else await login.mutateAsync({ username: normalized, password });
      await utils.auth.me.invalidate();
      toast.success(mode === "register" ? "Your GIGI account is ready. Welcome in." : "Welcome back to GIGI.");
      onAuthenticated();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Something went wrong. Please try again.");
    }
  };

  return (
    <div className="dialog-backdrop" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}>
      <section className="auth-dialog" role="dialog" aria-modal="true" aria-labelledby="auth-title">
        <button className="dialog-close icon-button" aria-label="Close" onClick={onClose}><X size={19} /></button>
        <div className="auth-emblem"><img src={GIGI_LOGO_URL} alt="" /></div>
        <p className="eyebrow">GIGI · MEME TOKEN ON BASE</p>
        <h2 id="auth-title">{mode === "register" ? "Come on in." : "Welcome back."}</h2>
        <p className="dialog-lede">{mode === "register" ? "Choose a username to join the GIGI community." : "Your GIGI community account is right where you left it."}</p>
        <form onSubmit={submit} className="auth-form">
          <label htmlFor="auth-username">Username</label>
          <div className="field-wrap"><UserRound size={17} /><input id="auth-username" value={username} onChange={event => setUsername(event.target.value)} autoComplete="username" required minLength={3} maxLength={20} placeholder="your_memename" /></div>
          <label htmlFor="auth-password">Password</label>
          <div className="field-wrap"><LockKeyhole size={17} /><input id="auth-password" type="password" value={password} onChange={event => setPassword(event.target.value)} autoComplete={mode === "register" ? "new-password" : "current-password"} required minLength={10} maxLength={128} placeholder="At least 10 characters" /></div>
          <p className="form-note">Username and password only. No email or wallet needed.</p>
          {error && <p className="form-error" role="alert">{error}</p>}
          <button className="button button-primary auth-submit" type="submit" disabled={busy}>{busy ? "One moment…" : mode === "register" ? "Create account" : "Log in"}</button>
        </form>
        <p className="auth-switch">{mode === "register" ? "Already part of the community?" : "New to GIGI?"} <button className="text-button" onClick={() => onModeChange(mode === "register" ? "login" : "register")}>{mode === "register" ? "Log in" : "Create an account"}</button></p>
      </section>
    </div>
  );
}
