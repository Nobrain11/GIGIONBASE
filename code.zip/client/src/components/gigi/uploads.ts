export function uploadImage(file: File, kind: "profile" | "meme", onProgress: (percent: number) => void) {
  return new Promise<{ imageUrl: string }>((resolve, reject) => {
    const request = new XMLHttpRequest();
    request.open("POST", `/api/upload/${kind}`);
    request.setRequestHeader("Content-Type", file.type);
    request.withCredentials = true;
    request.upload.onprogress = event => {
      if (event.lengthComputable) onProgress(Math.round((event.loaded / event.total) * 100));
    };
    request.onload = () => {
      let response: { imageUrl?: string; error?: string } = {};
      try { response = JSON.parse(request.responseText) as typeof response; } catch { /* the response may be empty */ }
      if (request.status >= 200 && request.status < 300 && response.imageUrl) {
        resolve({ imageUrl: response.imageUrl });
      } else {
        reject(new Error(response.error || (request.status === 413 ? "Choose an image smaller than 5 MB." : "The image could not be uploaded. Please try again.")));
      }
    };
    request.onerror = () => reject(new Error("Network error while uploading. Check your connection and try again."));
    request.ontimeout = () => reject(new Error("The upload took too long. Please try again."));
    request.timeout = 120_000;
    request.send(file);
  });
}

export function validateImage(file: File) {
  const allowed = ["image/jpeg", "image/png", "image/webp"];
  if (!allowed.includes(file.type)) return "Choose a JPG, PNG or WebP image.";
  if (file.size > 5 * 1024 * 1024) return "Choose an image smaller than 5 MB.";
  if (!file.size) return "That file is empty. Choose another image.";
  return null;
}
