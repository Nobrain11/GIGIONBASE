import { useState } from "react";
import { ArrowDown, ArrowRight, Copy, ExternalLink, MessageCircle, Sparkles } from "lucide-react";
import { Link } from "wouter";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { copyText, GIGI_LOGO_URL, relativeTime } from "./utils";

const CONTRACT = "0x0a39d88c49d47c111bed9fa7e9b988b8686f3222";
const COSMIC_BACKDROP = "/manus-storage/async-images/YX6LmQ43f9EbhgkfiuwSCz/image-1.webp";
const MASCOT_ART = "/manus-storage/async-images/T1zOIcmclgYsNVol6BHH1r/image-1.webp";

export function LandingHero() {
  return <section className="landing-hero" id="home" style={{ backgroundImage: `linear-gradient(90deg, rgba(4,10,25,.94) 0%, rgba(4,10,25,.78) 47%, rgba(4,10,25,.3) 100%), linear-gradient(0deg, rgba(4,10,25,.5), transparent 65%), url(${COSMIC_BACKDROP})` }}>
    <div className="landing-hero-inner">
      <div className="landing-hero-copy"><p className="landing-eyebrow"><span /> GIGI · MEME TOKEN ON BASE</p><h1>GIGI</h1><p className="landing-hero-tagline">THE CUTEST MEME ON BASE.</p><p className="landing-hero-body">GIGI is a meme token on Base network dedicated to the cutest and sweetest Chihuahua Gigi Marie.</p><p className="landing-hero-body landing-hero-follow">We’re building something different and unique. Stick around for the long ride.</p><div className="landing-hero-actions"><a className="button button-primary" href="#about">Explore GIGI <ArrowDown size={15} /></a><Link className="button button-glass" href="/feed">Enter the Feed <ArrowRight size={15} /></Link></div></div>
      <div className="landing-gigi-frame"><div className="landing-gigi-glow" /><img src={GIGI_LOGO_URL} alt="Gigi Marie, the Chihuahua behind GIGI" /><span className="landing-photo-caption">GIGI MARIE · THE ORIGINAL</span><img className="landing-mascot-overlay" src={MASCOT_ART} alt="" aria-hidden="true" /></div>
    </div>
    <div className="landing-hero-index" aria-hidden="true"><span>01</span><i /><span>THE LONG RIDE</span></div>
  </section>;
}

export function AboutSection() {
  return <section className="landing-section about-section" id="about">
    <div className="section-marker"><span>01</span><i /> THE GIGI STORY</div>
    <div className="about-story-layout"><div className="about-story-photo"><img src={GIGI_LOGO_URL} alt="Gigi Marie, a Chihuahua" /><span className="photo-corner photo-corner-a" /><span className="photo-corner photo-corner-b" /><span className="photo-photo-label">GIGI MARIE</span></div>
      <div className="about-story-copy"><p className="section-kicker">MEET GIGI <span aria-hidden="true">🐶</span></p><h2>One tiny dog.<br /><span>A big meme energy.</span></h2><p className="section-lede">GIGI is a meme token on Base dedicated to Gigi Marie, the cutest and sweetest Chihuahua.</p><p>The project is building something different and unique around memes, crypto culture, community, and creativity.</p><p className="about-story-note">GIGI + BASE + MEME CULTURE + COMMUNITY</p><Link href="/feed" className="inline-cta">Meet the community <ArrowRight size={16} /></Link></div></div>
  </section>;
}

export function TokenSection() {
  const [copied, setCopied] = useState(false);
  const copyContract = async () => {
    try { await copyText(CONTRACT); setCopied(true); toast.success("GIGI contract copied"); window.setTimeout(() => setCopied(false), 1800); }
    catch { toast.error("Couldn’t copy the contract address"); }
  };
  return <section className="landing-section token-section" id="token">
    <div className="section-marker"><span>02</span><i /> THE TOKEN</div>
    <div className="token-feature"><div className="token-feature-copy"><p className="section-kicker">ON BASE · BUILT FOR MEME CULTURE</p><h2>$GIGI <span>ON BASE</span></h2><p>A simple home for the essential token details. No invented market stats, no financial promises.</p></div><div className="token-feature-card"><div className="token-feature-head"><span className="token-network-mark">B</span><span className="token-chain-label">BASE NETWORK</span><Sparkles size={18} aria-hidden="true" /></div><div className="token-feature-fields"><div><span>TOKEN</span><strong>GIGI</strong></div><div><span>TICKER</span><strong>$GIGI</strong></div><div><span>NETWORK</span><strong>Base</strong></div></div><div className="token-address"><span>CONTRACT ADDRESS</span><code>{CONTRACT}</code><button type="button" className="button button-primary" onClick={copyContract}><Copy size={15} />{copied ? "Copied" : "Copy contract"}</button></div><p className="token-disclaimer">Always verify contract details before interacting with any token.</p></div></div>
  </section>;
}

export function CommunitySection() {
  const unavailable = (network: string) => toast.message(`Official ${network} link not configured`, { description: "GIGI will only link to verified community destinations." });
  return <section className="landing-section community-section" id="community">
    <div className="section-marker"><span>03</span><i /> THE PEOPLE
    </div>
    <div className="community-panel"><div className="community-orbit" aria-hidden="true" /><div className="community-content"><p className="section-kicker">MEMES BRING US TOGETHER</p><h2>THE GIGI<br /><span>COMMUNITY</span></h2><p>GIGI is more than a meme. It’s a community building something different on Base.</p><div className="community-actions"><button type="button" className="button button-outline" onClick={() => unavailable("X")}>Follow on X <ExternalLink size={14} /></button><button type="button" className="button button-outline" onClick={() => unavailable("community")}>Join the community <MessageCircle size={14} /></button><Link href="/feed" className="button button-primary">Enter the Feed <ArrowRight size={15} /></Link></div><p className="community-link-note">No official X or Telegram link has been supplied yet. We won’t point you to an unverified account.</p></div><div className="community-dog"><img src={MASCOT_ART} alt="Gigi, the Chihuahua mascot" /></div></div>
  </section>;
}

const ROADMAP = [
  { phase: "01", title: "GIGI ARRIVES", items: ["Establish the GIGI identity.", "Build awareness.", "Grow the community."] },
  { phase: "02", title: "MEME CULTURE", items: ["Expand the community meme culture.", "Launch and grow the GIGI Feed.", "Encourage community-created content."] },
  { phase: "03", title: "COMMUNITY GROWTH", items: ["Expand the GIGI community.", "Build new experiences.", "Continue growing across crypto culture."] },
  { phase: "04", title: "THE LONG RIDE", items: ["Continue building.", "Continue creating.", "Let the community help shape what comes next."] },
];

export function RoadmapSection() {
  return <section className="landing-section roadmap-section" id="roadmap">
    <div className="section-marker"><span>04</span><i /> THE JOURNEY</div>
    <div className="roadmap-heading"><div><p className="section-kicker">DIRECTION, NOT PROMISES</p><h2>STICK AROUND<br /><span>FOR THE LONG RIDE.</span></h2></div><p>We’re building something different and unique. The community helps shape what comes next.</p></div>
    <div className="roadmap-list">{ROADMAP.map((item, index) => <article className="roadmap-card" key={item.phase}><div className="roadmap-node"><span>{item.phase}</span><i /></div><div className="roadmap-card-content"><p>PHASE {item.phase}</p><h3>{item.title}</h3><ul>{item.items.map(point => <li key={point}>{point}</li>)}</ul></div><span className="roadmap-step" aria-hidden="true">0{index + 1}</span></article>)}</div>
    <p className="roadmap-caveat">These are development goals and direction, not guaranteed promises.</p>
  </section>;
}

export function MemeCultureSection() {
  const query = trpc.feed.list.useQuery({ limit: 3 });
  const posts = query.data?.items ?? [];
  return <section className="landing-section meme-preview-section" id="feed-preview">
    <div className="section-marker"><span>05</span><i /> THE CULTURE
    </div>
    <div className="meme-preview-heading"><div><p className="section-kicker">A COMMUNITY MAKES THE MEMES</p><h2>EVERYONE<br /><span>MEMES.</span></h2><p>The GIGI Feed is where the community creates, shares, and discovers crypto memes.</p></div><Link href="/feed" className="button button-primary">Enter the GIGI Feed <ArrowRight size={15} /></Link></div>
    {query.isLoading && <div className="preview-state">Finding the latest community memes…</div>}
    {query.isError && <div className="preview-state">Community posts aren’t available right now. <Link href="/feed">Open the Feed <ArrowRight size={14} /></Link></div>}
    {!query.isLoading && !query.isError && posts.length > 0 && <div className="meme-preview-grid">{posts.map(post => <Link key={post.id} href={`/meme/${post.id}`} className="meme-preview-card"><div className="meme-preview-image"><img src={post.imageUrl} alt={post.caption || `Meme by @${post.author.username}`} loading="lazy" /></div><div className="meme-preview-meta"><span>@{post.author.username} · {relativeTime(post.createdAt)}</span><span>{post.likeCount} likes</span></div><p>{post.caption || "A GIGI community meme."}</p></Link>)}</div>}
    {!query.isLoading && !query.isError && posts.length === 0 && <div className="meme-preview-empty"><img src={GIGI_LOGO_URL} alt="Gigi Marie, a Chihuahua" /><div><strong>The Feed is ready for its first meme.</strong><p>No community posts are available yet. When they arrive, they’ll show up here.</p></div></div>}
    <Link href="/feed" className="meme-preview-bottom-link">Browse the public Feed <ArrowRight size={16} /></Link>
  </section>;
}
