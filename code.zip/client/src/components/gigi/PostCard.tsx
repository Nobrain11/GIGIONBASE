import { useState } from "react";
import { Link } from "wouter";
import { formatDistanceToNow } from "date-fns";
import { Heart, MessageCircle, MoreHorizontal, Send, Share2, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import type { inferRouterOutputs } from "@trpc/server";
import type { AppRouter } from "../../../../server/routers";
import { useSite } from "./SiteShell";
import { initials, shareUrl } from "./utils";

type Outputs = inferRouterOutputs<AppRouter>;
export type MemePost = Outputs["feed"]["list"]["items"][number];
type Comment = Outputs["comments"]["list"][number];

export function Avatar({ src, username, small = false }: { src: string | null; username: string; small?: boolean }) {
  return <span className={`avatar${small ? " small" : ""}`}>{src ? <img src={src} alt={`${username} profile`} /> : initials(username)}</span>;
}

function timeAgo(value: Date) {
  try { return formatDistanceToNow(new Date(value), { addSuffix: true }); }
  catch { return "recently"; }
}

export default function PostCard({ post, onDeleted }: { post: MemePost; onDeleted?: () => void }) {
  const { user, openAuth } = useSite();
  const [commentsOpen, setCommentsOpen] = useState(false);
  const [draft, setDraft] = useState("");
  const utils = trpc.useUtils();
  const comments = trpc.comments.list.useQuery({ postId: post.id }, { enabled: commentsOpen, staleTime: 10_000 });
  const like = trpc.likes.toggle.useMutation({
    onSuccess: async () => { await utils.feed.invalidate(); },
    onError: error => toast.error(error.message || "Couldn’t update that like."),
  });
  const addComment = trpc.comments.add.useMutation({
    onSuccess: async () => {
      setDraft("");
      await Promise.all([utils.comments.list.invalidate({ postId: post.id }), utils.feed.invalidate()]);
      toast.success("Comment posted");
    },
    onError: error => toast.error(error.message || "Couldn’t post your comment."),
  });
  const removeComment = trpc.comments.delete.useMutation({
    onSuccess: async () => { await Promise.all([utils.comments.list.invalidate({ postId: post.id }), utils.feed.invalidate()]); toast.success("Comment removed"); },
    onError: error => toast.error(error.message || "Couldn’t remove that comment."),
  });
  const removePost = trpc.posts.delete.useMutation({
    onSuccess: async () => { await utils.feed.invalidate(); toast.success("Your meme was removed from the feed"); onDeleted?.(); },
    onError: error => toast.error(error.message || "Couldn’t remove that meme."),
  });

  const handleLike = () => {
    if (!user) { openAuth("login"); return; }
    like.mutate({ postId: post.id });
  };
  const handleShare = async () => {
    const url = `${window.location.origin}/meme/${post.id}`;
    try {
      const result = await shareUrl(url, `A GIGI meme by @${post.author.username}`);
      if (result === "copied") toast.success("Post link copied");
    } catch (error) {
      if (error instanceof Error && error.name === "AbortError") return;
      toast.error("Couldn’t share this link.");
    }
  };
  const submitComment = (event: React.FormEvent) => {
    event.preventDefault();
    if (!user) { openAuth("login"); return; }
    const content = draft.trim();
    if (!content) return;
    addComment.mutate({ postId: post.id, content });
  };
  const handleDelete = () => {
    if (window.confirm("Remove this meme from the feed?")) removePost.mutate({ id: post.id });
  };

  return (
    <article className="post-card" id={`meme-${post.id}`}>
      <div className="post-head">
        <Link href={`/profile/${post.author.username}`} aria-label={`View ${post.author.username}'s profile`}><Avatar src={post.author.avatarUrl} username={post.author.username} /></Link>
        <div className="post-author"><Link href={`/profile/${post.author.username}`}>@{post.author.username}</Link><time className="post-time" dateTime={new Date(post.createdAt).toISOString()}>{timeAgo(post.createdAt)}</time></div>
        {user?.id === post.userId && <button className="icon-button post-menu" aria-label="Delete your meme" title="Delete your meme" disabled={removePost.isPending} onClick={handleDelete}><Trash2 size={16} /></button>}
      </div>
      {post.caption && <p className="post-caption">{post.caption}</p>}
      <Link href={`/meme/${post.id}`} className="post-image-link" aria-label={`Open meme posted by ${post.author.username}`}><img className="post-image" src={post.imageUrl} alt={post.caption || `Meme posted by ${post.author.username}`} loading="lazy" /></Link>
      <div className="post-actions">
        <button className={`post-action ${post.likedByMe ? "liked" : ""}`} aria-label={post.likedByMe ? "Unlike this meme" : "Like this meme"} aria-pressed={post.likedByMe} onClick={handleLike} disabled={like.isPending}><Heart size={17} /><span>{post.likeCount}</span></button>
        <button className="post-action" aria-expanded={commentsOpen} aria-label={`${commentsOpen ? "Hide" : "Show"} ${post.commentCount} comments`} onClick={() => setCommentsOpen(open => !open)}><MessageCircle size={16} /><span>{post.commentCount}</span></button>
        <button className="post-action share-action" onClick={handleShare} aria-label="Share this meme"><Share2 size={16} /><span>Share</span></button>
      </div>
      {commentsOpen && <section className="comment-panel" aria-label="Comments">
        {comments.isLoading && <div className="inline-state">Loading the conversation…</div>}
        {comments.isError && <div className="error-state">Couldn’t load comments. <button className="text-button" onClick={() => void comments.refetch()}>Try again</button></div>}
        {comments.data && comments.data.length === 0 && <div className="inline-state">No comments yet. Start the conversation.</div>}
        {comments.data && comments.data.length > 0 && <div className="comment-list">{[...comments.data].reverse().map((comment: Comment) => <CommentRow key={comment.id} comment={comment} canDelete={user?.id === comment.userId} onDelete={() => removeComment.mutate({ id: comment.id })} />)}</div>}
        {user ? <form className="comment-form" onSubmit={submitComment}>
          <Avatar src={user.avatarUrl} username={user.username} small />
          <input value={draft} onChange={event => setDraft(event.target.value)} maxLength={500} placeholder="Write a comment…" aria-label="Write a comment" />
          <button type="submit" aria-label="Post comment" disabled={addComment.isPending || !draft.trim()}><Send size={15} /></button>
        </form> : <p className="comment-login">Want to join in? <button className="text-button" onClick={() => openAuth("login")}>Log in</button> to comment.</p>}
      </section>}
    </article>
  );
}

function CommentRow({ comment, canDelete, onDelete }: { comment: Comment; canDelete: boolean; onDelete: () => void }) {
  return <div className="comment-row">
    <Link href={`/profile/${comment.author.username}`}><Avatar src={comment.author.avatarUrl} username={comment.author.username} small /></Link>
    <div className="comment-body">
      <div className="comment-meta"><Link href={`/profile/${comment.author.username}`}><strong>@{comment.author.username}</strong></Link><time>{timeAgo(comment.createdAt)}</time>{canDelete && <button className="comment-delete" onClick={onDelete}>Remove</button>}</div>
      <p>{comment.content}</p>
    </div>
  </div>;
}
