import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { AlertCircle, Home } from "lucide-react";
import { useEffect } from "react";
import { useLocation } from "wouter";

// Hosting answers this path with HTTP 404 while still serving the app.
const NOT_FOUND_PATH = "/404";

// Render for unknown routes and for items the server confirmed missing (e.g. `/page/:id`).
// The redirect is irreversible: never render while loading, on other errors, or before auth resolves.
export default function NotFound() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    const robots = document.createElement("meta");
    robots.name = "robots";
    robots.content = "noindex";
    document.head.appendChild(robots);

    // Full-page navigation: a client-side route change sends no request, so no 404 status.
    if (window.location.pathname.replace(/\/$/, "") !== NOT_FOUND_PATH) {
      window.location.replace(NOT_FOUND_PATH);
    }

    return () => robots.remove();
  }, []);

  const handleGoHome = () => {
    setLocation("/");
  };

  return (
    <div className="page-shell" style={{ textAlign: "center" }}>
      <Card className="content-card" style={{ maxWidth: 500, margin: "0 auto" }}>
        <CardContent className="pt-8 pb-8 text-center">
          <div className="flex justify-center mb-6">
            <div className="relative">
              <div className="absolute inset-0 rounded-full animate-pulse" style={{ background: "rgba(76,156,255,.17)" }} />
              <AlertCircle className="relative h-16 w-16" style={{ color: "var(--lavender)" }} />
            </div>
          </div>

          <h1 className="page-title" style={{ fontSize: 45 }}>404</h1>

          <h2 className="section-heading" style={{ marginTop: 8 }}>
            That GIGI link isn’t here.
          </h2>

          <p className="page-lede" style={{ margin: "12px auto 22px" }}>
            This page may have moved or the meme may have been removed.
            <br />
            GIGI · MEME TOKEN ON BASE.
          </p>

          <div
            id="not-found-button-group"
            className="flex flex-col sm:flex-row gap-3 justify-center"
          >
            <Button
              onClick={handleGoHome}
              className="button button-primary"
            >
              <Home className="w-4 h-4 mr-2" />
              Go Home
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
