import { useEffect, useState } from "react";
import { ArrowLeft, Copy } from "lucide-react";
import { Link } from "wouter";
import { toast } from "sonner";
import { GIGI_LOGO_URL, copyText } from "@/components/gigi/utils";

const CONTRACT = "0x0a39d88c49d47c111bed9fa7e9b988b8686f3222";

export default function AboutPage() {
  const [copied, setCopied] = useState(false);
  useEffect(() => { document.title = "About Gigi — GIGI on Base"; }, []);
  const copyContract = async () => {
    try { await copyText(CONTRACT); setCopied(true); toast.success("GIGI contract copied"); window.setTimeout(() => setCopied(false), 1800); }
    catch { toast.error("Couldn’t copy the contract address"); }
  };
  return <div className="page-shell wide">
    <Link href="/" className="side-about" style={{ marginBottom: 18 }}><ArrowLeft size={15} /> Back to GIGI</Link>
    <section className="about-hero">
      <div className="about-hero-copy"><p className="page-eyebrow">GIGI · MEME TOKEN ON BASE</p><h1>MEET GIGI <span>🐶</span></h1><p>GIGI is a meme token on Base dedicated to Gigi Marie, the cutest and sweetest Chihuahua.</p><p>We’re building something different and unique, stick around for the long ride.</p></div>
      <img src={GIGI_LOGO_URL} alt="Gigi Marie, a Chihuahua" />
    </section>
    <div className="about-story">
      <section className="story-note"><p className="page-eyebrow">MEME CULTURE</p><h2>GIGI + BASE + COMMUNITY.</h2><p>The project is building something different and unique around memes, crypto culture, community, and creativity.</p></section>
      <section className="story-note"><p className="page-eyebrow">THE FEED</p><h2>Culture is made together.</h2><p>Browse the public GIGI Feed, discover community memes and join the conversation. No wallet is needed to browse.</p><Link href="/feed" className="inline-cta">Enter the Feed <ArrowLeft size={15} style={{ transform: "rotate(180deg)" }} /></Link></section>
    </div>
    <section className="token-card" aria-labelledby="token-title">
      <div className="token-card-head"><div><p>$GIGI ON BASE</p><h2 id="token-title">Token details</h2></div></div>
      <div className="token-grid"><div className="token-field"><span>Token</span><strong>GIGI</strong></div><div className="token-field"><span>Ticker</span><strong>$GIGI</strong></div><div className="token-field"><span>Network</span><strong>Base</strong></div></div>
      <div className="contract-box"><code>{CONTRACT}</code><button className="button button-primary" onClick={copyContract}><Copy size={15} />{copied ? "Copied" : "Copy contract"}</button></div>
      <p className="form-hint" style={{ marginTop: 12 }}>Only verified official links will be listed. No prices, trading statistics or financial promises are shown.</p>
    </section>
  </div>;
}
