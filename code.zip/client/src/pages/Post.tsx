import { ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import PostCard from "@/components/gigi/PostCard";
import NotFound from "./NotFound";

export default function PostPage({ id: rawId }: { id: string }) {
  const id = Number(rawId);
  const post = trpc.feed.get.useQuery({ id }, { enabled: Number.isInteger(id) && id > 0 });
  if (!Number.isInteger(id) || id < 1) return <NotFound />;
  if (post.isLoading) return <div className="page-shell"><div className="loading-state"><span className="spinner" />Opening this meme…</div></div>;
  if (post.isError && post.error.data?.code === "NOT_FOUND") return <NotFound />;
  if (post.isError) return <div className="page-shell"><div className="error-state">Couldn’t open this meme right now. <button className="text-button" onClick={() => void post.refetch()}>Try again</button></div></div>;
  if (!post.data) return null;
  return <div className="page-shell"><Link href="/feed" className="side-about" style={{ marginBottom: 17 }}><ArrowLeft size={15} /> Back to the Feed</Link><PostCard post={post.data} /></div>;
}
