import { useEffect, useState, type ChangeEvent } from "react";
import { ArrowLeft, ImagePlus, X } from "lucide-react";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { useSite } from "@/components/gigi/SiteShell";
import { uploadImage, validateImage } from "@/components/gigi/uploads";

export default function CreatePostPage() {
  const { user, loading, openAuth } = useSite();
  const [, setLocation] = useLocation();
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState("");
  const [caption, setCaption] = useState("");
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState("");
  const utils = trpc.useUtils();
  const createPost = trpc.posts.create.useMutation();
  const busy = createPost.isPending || progress > 0;

  useEffect(() => {
    if (!file) { setPreview(""); return; }
    const url = URL.createObjectURL(file);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  const selectFile = (event: ChangeEvent<HTMLInputElement>) => {
    setError("");
    const chosen = event.target.files?.[0];
    event.target.value = "";
    if (!chosen) return;
    const problem = validateImage(chosen);
    if (problem) { setError(problem); setFile(null); return; }
    setFile(chosen);
  };

  const publish = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!user) { openAuth("login"); return; }
    setError("");
    if (!file) { setError("Choose a meme image before publishing."); return; }
    try {
      setProgress(1);
      const uploaded = await uploadImage(file, "meme", setProgress);
      const result = await createPost.mutateAsync({ caption: caption.trim(), imageUrl: uploaded.imageUrl });
      await Promise.all([utils.feed.invalidate(), utils.profile.invalidate()]);
      toast.success("Your meme is in the feed.");
      setLocation(`/meme/${result.id}`);
    } catch (cause) {
      const message = cause instanceof Error ? cause.message : "Your meme could not be published. Please try again.";
      setError(message);
      toast.error(message);
    } finally {
      setProgress(0);
    }
  };

  if (loading) return <div className="page-shell"><div className="loading-state"><span className="spinner" />Checking your GIGI account…</div></div>;
  if (!user) return <div className="page-shell"><p className="page-eyebrow">POST A MEME</p><h1 className="page-title">Join the GIGI community.</h1><p className="page-lede">Create a free username and password to share memes with the community. No email or wallet needed.</p><button className="button button-primary" onClick={() => openAuth("register")}>Create an account</button></div>;

  return <div className="page-shell">
    <Link href="/feed" className="side-about" style={{ marginBottom: 19 }}><ArrowLeft size={15} /> Back to the Feed</Link>
    <p className="page-eyebrow">YOUR TURN</p><h1 className="page-title">Post a meme.</h1><p className="page-lede">A good caption is optional. A good laugh is not.</p>
    <form className="content-card upload-card" onSubmit={publish}>
      <label className="upload-zone" htmlFor="meme-file">
        {preview ? <img src={preview} alt="Preview of the meme you selected" /> : <><ImagePlus size={27} /><strong>Choose a meme from your device</strong><span>JPG, PNG or WebP · up to 5 MB</span></>}
        <input id="meme-file" type="file" accept="image/jpeg,image/png,image/webp" onChange={selectFile} disabled={busy} />
      </label>
      {file && <div className="file-selected"><span>{file.name} · {(file.size / (1024 * 1024)).toFixed(2)} MB</span><button type="button" className="icon-button" aria-label="Remove selected image" disabled={busy} onClick={() => setFile(null)}><X size={16} /></button></div>}
      <div className="form-block"><label htmlFor="meme-caption">Caption <span className="form-hint">(optional)</span></label><textarea id="meme-caption" value={caption} onChange={event => setCaption(event.target.value)} maxLength={500} placeholder="What’s the meme saying?" /><span className="form-hint">{caption.length}/500</span></div>
      {progress > 0 && <div className="upload-progress" aria-live="polite"><div className="form-hint">Uploading your image… {progress}%</div><div className="progress-track"><div className="progress-bar" style={{ width: `${progress}%` }} /></div></div>}
      {error && <p className="form-error" role="alert" style={{ marginTop: 12 }}>{error}</p>}
      <div className="submit-row"><span className="form-hint">Your meme will be public in the community feed.</span><button className="button button-primary" type="submit" disabled={busy || !file}>{busy ? "Publishing…" : "Publish meme"}</button></div>
    </form>
  </div>;
}
