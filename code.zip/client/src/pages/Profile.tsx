import { useEffect, useState, type ChangeEvent } from "react";
import { CalendarDays, ImagePlus, Save, Settings2 } from "lucide-react";
import { Link } from "wouter";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { Avatar, type MemePost } from "@/components/gigi/PostCard";
import { useSite } from "@/components/gigi/SiteShell";
import { uploadImage, validateImage } from "@/components/gigi/uploads";
import NotFound from "./NotFound";

export default function ProfilePage({ username }: { username: string }) {
  const { user, openAuth } = useSite();
  const [cursor, setCursor] = useState<number | undefined>(undefined);
  const [profilePosts, setProfilePosts] = useState<MemePost[]>([]);
  const profile = trpc.profile.get.useQuery({ username, cursor }, { placeholderData: previous => previous });
  const utils = trpc.useUtils();
  const update = trpc.profile.update.useMutation();
  const [editing, setEditing] = useState(false);
  const [bio, setBio] = useState("");
  const [selectedAvatar, setSelectedAvatar] = useState<File | null>(null);
  const [avatarPreview, setAvatarPreview] = useState("");
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState("");
  const ownProfile = !!user && profile.data?.id === user.id;
  const validUsername = /^[a-z0-9_]{3,20}$/i.test(username);

  useEffect(() => { if (profile.data) setBio(profile.data.bio); }, [profile.data?.bio]);
  useEffect(() => {
    if (!profile.data) return;
    setProfilePosts(current => {
      if (cursor === undefined) return profile.data.posts;
      const seen = new Set(current.map(post => post.id));
      return [...current, ...profile.data.posts.filter(post => !seen.has(post.id))];
    });
  }, [profile.data, cursor]);
  useEffect(() => {
    if (!selectedAvatar) { setAvatarPreview(""); return; }
    const url = URL.createObjectURL(selectedAvatar);
    setAvatarPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [selectedAvatar]);
  const chooseAvatar = (event: ChangeEvent<HTMLInputElement>) => {
    setError("");
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    const problem = validateImage(file);
    if (problem) { setError(problem); return; }
    setSelectedAvatar(file);
  };
  const saveProfile = async (event: React.FormEvent) => {
    event.preventDefault();
    setError("");
    try {
      let avatarUrl: string | undefined;
      if (selectedAvatar) {
        setProgress(1);
        avatarUrl = (await uploadImage(selectedAvatar, "profile", setProgress)).imageUrl;
      }
      await update.mutateAsync({ bio: bio.trim(), ...(avatarUrl ? { avatarUrl } : {}) });
      await Promise.all([utils.profile.get.invalidate({ username }), utils.auth.me.invalidate()]);
      setSelectedAvatar(null);
      setEditing(false);
      toast.success("Your profile is up to date.");
    } catch (cause) {
      const message = cause instanceof Error ? cause.message : "Couldn’t update your profile.";
      setError(message);
      toast.error(message);
    } finally { setProgress(0); }
  };

  if (!validUsername || (profile.isError && profile.error.data?.code === "NOT_FOUND")) return <NotFound />;
  if (profile.isLoading) return <div className="page-shell"><div className="loading-state"><span className="spinner" />Loading this GIGI community profile…</div></div>;
  if (profile.isError) return <div className="page-shell"><div className="error-state">This profile couldn’t load right now. <button className="text-button" onClick={() => void profile.refetch()}>Try again</button></div></div>;
  if (!profile.data) return null;

  const profileData = profile.data;
  return <div className="page-shell wide">
    <section className="profile-banner">
      <Avatar src={profileData.avatarUrl} username={profileData.username} />
      <div className="profile-info"><p className="page-eyebrow">GIGI COMMUNITY MEMBER</p><h1>@{profileData.username}</h1><p>{profileData.bio || (ownProfile ? "Add a short bio to tell the GIGI community about yourself." : "This member hasn’t added a bio yet.")}</p><div style={{ display: "flex", alignItems: "center", gap: 13, flexWrap: "wrap" }}><span className="profile-joined"><CalendarDays size={13} style={{ verticalAlign: "-2px", marginRight: 4 }} />Joined {new Date(profileData.createdAt).toLocaleDateString(undefined, { month: "long", year: "numeric" })}</span><span className="profile-post-count">{profileData.postCount} {profileData.postCount === 1 ? "meme" : "memes"}</span></div></div>
      {ownProfile && <button className="button button-secondary" onClick={() => { setEditing(value => !value); setSelectedAvatar(null); setError(""); }}><Settings2 size={15} />{editing ? "Close" : "Edit profile"}</button>}
      {!user && <button className="button button-secondary" onClick={() => openAuth("register")}>Join in</button>}
    </section>

    {editing && ownProfile && <form className="profile-edit" onSubmit={saveProfile}>
      <div className="profile-edit-grid">
        <label className="avatar-upload"><input type="file" accept="image/jpeg,image/png,image/webp" onChange={chooseAvatar} /><span className="avatar">{avatarPreview ? <img src={avatarPreview} alt="Selected profile picture preview" /> : profileData.avatarUrl ? <img src={profileData.avatarUrl} alt="Current profile picture" /> : username.slice(0, 2).toUpperCase()}</span><span><ImagePlus size={13} style={{ verticalAlign: "-2px", marginRight: 4 }} />Change picture</span></label>
        <div className="form-block" style={{ marginTop: 0 }}><label htmlFor="profile-bio">Your bio</label><textarea id="profile-bio" value={bio} onChange={event => setBio(event.target.value)} maxLength={280} placeholder="A little about you and your corner of crypto…" /><span className="form-hint">{bio.length}/280 · JPG, PNG or WebP image up to 5 MB</span></div>
      </div>
      {progress > 0 && <div className="upload-progress" style={{ marginTop: 12 }}><div className="form-hint">Uploading profile picture… {progress}%</div><div className="progress-track"><div className="progress-bar" style={{ width: `${progress}%` }} /></div></div>}
      {error && <p className="form-error" role="alert">{error}</p>}
      <div className="submit-row"><span className="form-hint">Only you can edit this profile.</span><button className="button button-primary" type="submit" disabled={update.isPending || progress > 0}><Save size={15} />Save profile</button></div>
    </form>}

    <div className="profile-section-heading"><h2>Published memes</h2><span>Shared with the GIGI community</span></div>
    {profilePosts.length === 0 && profileData.postCount === 0 ? <div className="empty-state"><h3>No memes yet.</h3><p>{ownProfile ? "Your posts will collect here when you share your first meme." : "This member hasn’t published a meme yet."}</p>{ownProfile && <Link className="button button-primary" href="/post/new">Post a meme</Link>}</div> : <div className="profile-post-grid">{profilePosts.map((post: MemePost) => <Link key={post.id} href={`/meme/${post.id}`} className="profile-post" aria-label={`Open meme: ${post.caption || `meme ${post.id}`}`}><img src={post.imageUrl} alt={post.caption || `Meme by ${profileData.username}`} loading="lazy" /></Link>)}</div>}
    {profile.data.nextCursor && <button className="button button-secondary" style={{ display: "flex", margin: "16px auto 0" }} onClick={() => setCursor(profile.data?.nextCursor ?? undefined)} disabled={profile.isFetching}>{profile.isFetching ? "Loading…" : "Load more memes"}</button>}
  </div>;
}
