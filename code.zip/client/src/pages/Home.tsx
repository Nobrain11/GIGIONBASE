import { useEffect } from "react";
import { AboutSection, CommunitySection, LandingHero, MemeCultureSection, RoadmapSection, TokenSection } from "@/components/gigi/MarketingSections";

export default function HomePage() {
  useEffect(() => {
    document.title = "GIGI — The Cutest Meme on Base";
    const targetId = decodeURIComponent(window.location.hash.slice(1));
    if (!targetId) return;
    const frame = window.requestAnimationFrame(() => document.getElementById(targetId)?.scrollIntoView({ block: "start" }));
    return () => window.cancelAnimationFrame(frame);
  }, []);

  return <div className="landing-page">
    <LandingHero />
    <AboutSection />
    <TokenSection />
    <CommunitySection />
    <RoadmapSection />
    <MemeCultureSection />
  </div>;
}
