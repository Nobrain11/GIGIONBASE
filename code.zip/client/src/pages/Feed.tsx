import { useEffect, useState } from "react";
import { Link } from "wouter";
import { ArrowRight, Copy } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import PostCard, { type MemePost } from "@/components/gigi/PostCard";
import { useSite } from "@/components/gigi/SiteShell";
import { copyText, GIGI_LOGO_URL } from "@/components/gigi/utils";

const MASCOT = "/manus-storage/async-images/T1zOIcmclgYsNVol6BHH1r/image-1.webp";
const CONTRACT = "0x0a39d88c49d47c111bed9fa7e9b988b8686f3222";

function FeedSidebar() {
  const [copied, setCopied] = useState(false);
  const copyContract = async () => {
    try {
      await copyText(CONTRACT);
      setCopied(true);
      toast.success("Contract address copied");
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      toast.error("Couldn’t copy the contract address");
    }
  };
  return <aside className="feed-side" aria-label="About GIGI">
    <section className="side-card side-gigi"><img src={MASCOT} alt="Gigi the Chihuahua" /><div><p className="eyebrow">MEET GIGI</p><h3>GIGI on Base.</h3><p>A meme token dedicated to Chihuahua Gigi Marie.</p><Link href="/#about" className="side-about">About the project <ArrowRight size={14} /></Link></div></section>
    <section className="side-card"><div className="side-onbase">$GIGI · BASE</div><h3 style={{ marginTop: 9 }}>Token details</h3><p>Just the basics. No made-up numbers.</p><div className="side-contract"><code>{CONTRACT}</code><button className="text-button" onClick={copyContract}><Copy size={13} style={{ verticalAlign: "-2px", marginRight: 5 }} />{copied ? "Copied" : "Copy contract"}</button></div></section>
    <section className="side-card"><h3>Made by the community</h3><p>Browse freely, share a meme and meet the people behind the punchlines.</p><Link href="/" className="side-about">Back to GIGI <ArrowRight size={14} /></Link></section>
  </aside>;
}

export default function FeedPage() {
  const { user, openAuth } = useSite();
  const [cursor, setCursor] = useState<number | undefined>(undefined);
  const [posts, setPosts] = useState<MemePost[]>([]);
  const feed = trpc.feed.list.useQuery({ limit: 12, cursor });
  useEffect(() => { document.title = "GIGI Feed — Community Memes"; }, []);
  useEffect(() => {
    if (!feed.data) return;
    setPosts(current => {
      if (cursor === undefined) return feed.data.items;
      const seen = new Set(current.map(post => post.id));
      const latest = new Map(feed.data.items.map(post => [post.id, post]));
      return [...current.map(post => latest.get(post.id) ?? post), ...feed.data.items.filter(post => !seen.has(post.id))];
    });
  }, [feed.data, cursor]);

  return <div className="page-shell home-shell feed-page">
    <section className="feed-intro">
      <div><p className="hero-overline">GIGI · MEME TOKEN ON BASE</p><h1>THE GIGI <span>FEED.</span></h1><p>Browse the memes, meet the community, and add your own when you’re ready.</p></div>
      <div className="feed-intro-actions"><Link className="button button-primary" href="/post/new">＋ Post a meme</Link><Link className="button button-secondary" href="/">Back to GIGI</Link></div>
    </section>
    <div className="feed-heading"><div><h2>Community memes</h2><p>Fresh posts from the GIGI community.</p></div><span className="feed-count-note">Public to browse · GIGI on Base</span></div>
    <div className="feed-layout">
      <section className="feed-list" aria-label="Community meme feed" aria-busy={feed.isLoading}>
        {feed.isLoading && posts.length === 0 && <div className="loading-state"><span className="spinner" /> Finding the latest memes…</div>}
        {feed.isError && posts.length === 0 && <div className="error-state" role="alert">The feed couldn’t load right now. <button className="text-button" onClick={() => void feed.refetch()}>Try again</button></div>}
        {!feed.isLoading && !feed.isError && posts.length === 0 && <div className="empty-state"><img src={GIGI_LOGO_URL} alt="Gigi Marie, a Chihuahua" /><h3>The feed starts here.</h3><p>No memes yet. Be the first to share a little GIGI energy.</p><Link className="button button-primary" href="/post/new">Post the first meme <ArrowRight size={14} /></Link></div>}
        {posts.map(post => <PostCard key={post.id} post={post} onDeleted={() => { setPosts(current => current.filter(item => item.id !== post.id)); void feed.refetch(); }} />)}
        {feed.isError && posts.length > 0 && <div className="error-state">Couldn’t load more memes. <button className="text-button" onClick={() => void feed.refetch()}>Try again</button></div>}
        {feed.data?.nextCursor && !feed.isError && <button className="button button-secondary" onClick={() => setCursor(feed.data?.nextCursor ?? undefined)} disabled={feed.isFetching}>{feed.isFetching ? <><span className="spinner" /> Loading…</> : "Load more memes"}</button>}
      </section>
      <FeedSidebar />
    </div>
    {!user && <p className="feed-login-note">Browsing is open. <button className="text-button" onClick={() => openAuth("register")}>Join the community</button> when you’re ready to post, like, or comment.</p>}
  </div>;
}
