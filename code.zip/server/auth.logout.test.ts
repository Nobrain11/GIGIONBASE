import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import { APP_SESSION_COOKIE } from "./auth";
import type { TrpcContext } from "./_core/context";

type CookieCall = { name: string; options: Record<string, unknown> };

function createAuthContext(): { ctx: TrpcContext; clearedCookies: CookieCall[] } {
  const clearedCookies: CookieCall[] = [];
  const req = {
    protocol: "http",
    headers: {},
    get: (name: string) => name.toLowerCase() === "origin" ? "https://preview.example" : undefined,
  } as unknown as TrpcContext["req"];
  const ctx = {
    user: null,
    req,
    res: {
      clearCookie: (name: string, options: Record<string, unknown>) => clearedCookies.push({ name, options }),
    } as unknown as TrpcContext["res"],
  } satisfies TrpcContext;
  return { ctx, clearedCookies };
}

describe("auth.logout", () => {
  it("clears the app-owned session cookie with the HTTPS Preview attributes", async () => {
    const { ctx, clearedCookies } = createAuthContext();
    const result = await appRouter.createCaller(ctx).auth.logout();
    expect(result).toEqual({ success: true });
    expect(clearedCookies).toHaveLength(1);
    expect(clearedCookies[0]?.name).toBe(APP_SESSION_COOKIE);
    expect(clearedCookies[0]?.options).toMatchObject({ secure: true, sameSite: "none", httpOnly: true, path: "/" });
  });
});
