import "dotenv/config";
import express from "express";
import { createServer } from "http";
import { randomUUID } from "node:crypto";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { appRouter } from "../routers";
import { resolveAccount } from "../auth";
import { storagePut } from "../storage";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";

const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
const acceptedTypes: Record<string, { extension: string; signature: (bytes: Buffer) => boolean }> = {
  "image/jpeg": { extension: "jpg", signature: bytes => bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff },
  "image/png": { extension: "png", signature: bytes => bytes.length >= 8 && bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])) },
  "image/webp": { extension: "webp", signature: bytes => bytes.length >= 12 && bytes.toString("ascii", 0, 4) === "RIFF" && bytes.toString("ascii", 8, 12) === "WEBP" },
};

function makeLimiter(limit: number, windowMs: number) {
  const events = new Map<string, number[]>();
  return (key: string) => {
    const now = Date.now();
    const recent = (events.get(key) ?? []).filter(time => now - time < windowMs);
    if (recent.length >= limit) {
      events.set(key, recent);
      return Math.ceil((windowMs - (now - recent[0]!)) / 1000);
    }
    recent.push(now);
    events.set(key, recent);
    if (events.size > 3000) {
      for (const [entry, timestamps] of events) {
        if (timestamps.every(time => now - time >= windowMs)) events.delete(entry);
      }
    }
    return 0;
  };
}
const allowUpload = makeLimiter(20, 60 * 60 * 1000);

async function startServer() {
  const app = express();
  const server = createServer(app);
  app.use(express.json({ limit: "200kb" }));
  app.use(express.urlencoded({ limit: "200kb", extended: true }));
  app.get("/api/health", (_req, res) => res.json({ status: "ok" }));

  app.post("/api/upload/:kind", express.raw({ type: "image/*", limit: MAX_IMAGE_BYTES }), async (req, res) => {
    try {
      const account = await resolveAccount(req);
      if (!account) return res.status(401).json({ error: "Sign in to upload an image." });
      const waitSeconds = allowUpload(`${account.id}:${req.ip}`);
      if (waitSeconds > 0) {
        res.setHeader("Retry-After", String(waitSeconds));
        return res.status(429).json({ error: "Too many uploads. Please try again later." });
      }
      if (req.params.kind !== "profile" && req.params.kind !== "meme") {
        return res.status(400).json({ error: "Unknown upload type." });
      }
      const file = Buffer.isBuffer(req.body) ? req.body : Buffer.alloc(0);
      if (!file.length || file.length > MAX_IMAGE_BYTES) {
        return res.status(413).json({ error: "Choose an image smaller than 5 MB." });
      }
      const mime = String(req.get("content-type") ?? "").split(";")[0]!.trim().toLowerCase();
      const format = acceptedTypes[mime];
      if (!format || !format.signature(file)) {
        return res.status(415).json({ error: "Only valid JPG, PNG or WebP images are supported." });
      }
      const category = req.params.kind === "profile" ? "profiles" : "posts";
      const stored = await storagePut(
        `gigi/${account.id}/${category}/${randomUUID()}.${format.extension}`,
        file,
        mime,
      );
      return res.status(201).json({ imageUrl: stored.url });
    } catch (error) {
      if ((error as { type?: string })?.type === "entity.too.large") {
        return res.status(413).json({ error: "Choose an image smaller than 5 MB." });
      }
      console.error("[Upload] Image upload failed", error);
      return res.status(503).json({ error: "The image could not be uploaded right now. Please try again." });
    }
  });

  app.use(
    "/api/trpc",
    createExpressMiddleware({ router: appRouter, createContext }),
  );
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const port = Number(process.env.PORT || "3000");
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("Invalid PORT");
  server.on("error", error => { console.error("Server failed:", error.message); process.exit(1); });
  server.listen(port, "0.0.0.0", () => console.log(`Server listening on port ${port}`));
}

startServer().catch(error => { console.error(error); process.exit(1); });
