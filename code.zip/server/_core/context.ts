import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { PublicAccount } from "../auth";
import { resolveAccount } from "../auth";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: PublicAccount | null;
};

export async function createContext(opts: CreateExpressContextOptions): Promise<TrpcContext> {
  let user: PublicAccount | null = null;
  try {
    user = await resolveAccount(opts.req);
  } catch (error) {
    // Public feed pages remain usable if the session store is temporarily unavailable.
    console.error("[Session] Account lookup failed", error);
  }
  return { req: opts.req, res: opts.res, user };
}
