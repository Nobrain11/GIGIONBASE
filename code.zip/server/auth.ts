import { createHash, randomBytes } from "node:crypto";
import type { Request, Response } from "express";
import { and, eq, gt } from "drizzle-orm";
import { gigiSessions, gigiUsers } from "../drizzle/schema";
import { getDb } from "./db";

export const APP_SESSION_COOKIE = "gigi_session";
const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000;

export type PublicAccount = {
  id: number;
  username: string;
  avatarUrl: string | null;
  bio: string;
  createdAt: Date;
};

export function sessionCookieOptions(req: Request) {
  const origin = req.get("origin") ?? req.get("referer") ?? "";
  const secureContext = /^https:\/\//i.test(origin);
  return {
    httpOnly: true,
    path: "/",
    sameSite: secureContext ? ("none" as const) : ("lax" as const),
    secure: secureContext,
    maxAge: SESSION_TTL_MS,
  };
}

export function readSessionToken(req: Request): string | null {
  const header = req.headers.cookie;
  if (!header) return null;
  for (const pair of header.split(";")) {
    const [name, ...parts] = pair.trim().split("=");
    if (name === APP_SESSION_COOKIE) {
      const token = parts.join("=");
      return token && /^[A-Za-z0-9_-]{40,60}$/.test(token) ? token : null;
    }
  }
  return null;
}

function hashToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

export async function resolveAccount(req: Request): Promise<PublicAccount | null> {
  const token = readSessionToken(req);
  if (!token) return null;
  const db = await getDb();
  if (!db) return null;
  const [row] = await db
    .select({
      id: gigiUsers.id,
      username: gigiUsers.username,
      avatarUrl: gigiUsers.avatarUrl,
      bio: gigiUsers.bio,
      createdAt: gigiUsers.createdAt,
    })
    .from(gigiSessions)
    .innerJoin(gigiUsers, eq(gigiSessions.userId, gigiUsers.id))
    .where(and(eq(gigiSessions.tokenHash, hashToken(token)), gt(gigiSessions.expiresAt, new Date())))
    .limit(1);
  return row ?? null;
}

export async function createAccountSession(userId: number, req: Request, res: Response) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const token = randomBytes(32).toString("base64url");
  const expiresAt = new Date(Date.now() + SESSION_TTL_MS);
  await db.insert(gigiSessions).values({ userId, tokenHash: hashToken(token), expiresAt });
  res.cookie(APP_SESSION_COOKIE, token, sessionCookieOptions(req));
}

export async function clearAccountSession(req: Request, res: Response) {
  const token = readSessionToken(req);
  const db = await getDb();
  if (token && db) {
    await db.delete(gigiSessions).where(eq(gigiSessions.tokenHash, hashToken(token)));
  }
  res.clearCookie(APP_SESSION_COOKIE, { ...sessionCookieOptions(req), maxAge: undefined });
}
