import { createHash, randomBytes, scrypt as scryptCallback, timingSafeEqual } from "node:crypto";
import { and, count, desc, eq, isNull, lt, sql } from "drizzle-orm";
import { z } from "zod";
import { gigiComments, gigiLikes, gigiPosts, gigiUsers } from "../drizzle/schema";
import { clearAccountSession, createAccountSession } from "./auth";
import { getDb } from "./db";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";

const PASSWORD_MIN = 10;
const USERNAME = z.string().trim().toLowerCase().min(3).max(20).regex(/^[a-z0-9_]+$/, "Use 3–20 letters, numbers or underscores.");
const credentials = z.object({ username: USERNAME, password: z.string().min(PASSWORD_MIN).max(128) });
const accountFields = {
  id: gigiUsers.id,
  username: gigiUsers.username,
  avatarUrl: gigiUsers.avatarUrl,
  bio: gigiUsers.bio,
  createdAt: gigiUsers.createdAt,
};

function createRateLimiter(limit: number, windowMs: number) {
  const buckets = new Map<string, { started: number; count: number }>();
  return (key: string) => {
    const now = Date.now();
    const bucket = buckets.get(key);
    if (!bucket || now - bucket.started >= windowMs) {
      buckets.set(key, { started: now, count: 1 });
      return 0;
    }
    if (bucket.count >= limit) return Math.max(1, Math.ceil((windowMs - (now - bucket.started)) / 1000));
    bucket.count += 1;
    if (buckets.size > 4000) {
      for (const [entry, value] of buckets) if (now - value.started >= windowMs) buckets.delete(entry);
    }
    return 0;
  };
}
const allowRegister = createRateLimiter(5, 60 * 60 * 1000);
const allowLogin = createRateLimiter(10, 15 * 60 * 1000);
const allowPost = createRateLimiter(8, 60 * 60 * 1000);
const allowComment = createRateLimiter(20, 60 * 60 * 1000);
const allowLike = createRateLimiter(120, 60 * 60 * 1000);

function enforceRateLimit(waitSeconds: number, message: string) {
  if (waitSeconds > 0) throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: `${message} Try again in ${Math.ceil(waitSeconds / 60)} minutes.` });
}

function getIp(req: { ip?: string; headers: Record<string, unknown> }) {
  return req.ip || "unknown";
}

function derivePassword(password: string, salt: Buffer) {
  return new Promise<Buffer>((resolve, reject) => {
    scryptCallback(password, salt, 64, (error, key) => error ? reject(error) : resolve(key as Buffer));
  });
}

async function hashPassword(password: string) {
  const salt = randomBytes(16);
  const hash = await derivePassword(password, salt);
  return `scrypt$${salt.toString("hex")}$${hash.toString("hex")}`;
}

async function verifyPassword(password: string, stored: string) {
  const [scheme, saltText, hashText] = stored.split("$");
  if (scheme !== "scrypt" || !saltText || !hashText || !/^[a-f0-9]{32}$/.test(saltText) || !/^[a-f0-9]{128}$/.test(hashText)) return false;
  const expected = Buffer.from(hashText, "hex");
  const actual = await derivePassword(password, Buffer.from(saltText, "hex"));
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}

function requireDatabase() {
  return getDb().then(database => {
    if (!database) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "The community database is not available yet." });
    return database;
  });
}

function imageBelongsToUser(imageUrl: string, userId: number, category: "posts" | "profiles") {
  return imageUrl.startsWith(`/manus-storage/gigi/${userId}/${category}/`) && imageUrl.length <= 512;
}

async function loadPostRows(options: { limit: number; cursor?: number; userId?: number; authorId?: number }) {
  const db = await requireDatabase();
  const conditions = [isNull(gigiPosts.deletedAt)];
  if (options.cursor !== undefined) conditions.push(lt(gigiPosts.id, options.cursor));
  if (options.authorId !== undefined) conditions.push(eq(gigiPosts.userId, options.authorId));
  const rows = await db
    .select({
      id: gigiPosts.id,
      userId: gigiPosts.userId,
      caption: gigiPosts.caption,
      imageUrl: gigiPosts.imageUrl,
      createdAt: gigiPosts.createdAt,
      authorUsername: gigiUsers.username,
      authorAvatarUrl: gigiUsers.avatarUrl,
      likeCount: sql<number>`(SELECT COUNT(*) FROM gigi_likes AS likes WHERE likes.postId = ${gigiPosts.id})`,
      commentCount: sql<number>`(SELECT COUNT(*) FROM gigi_comments AS comments WHERE comments.postId = ${gigiPosts.id} AND comments.deletedAt IS NULL)`,
      likedByMe: options.userId === undefined
        ? sql<number>`0`
        : sql<number>`EXISTS (SELECT 1 FROM gigi_likes AS mine WHERE mine.postId = ${gigiPosts.id} AND mine.userId = ${options.userId})`,
    })
    .from(gigiPosts)
    .innerJoin(gigiUsers, eq(gigiPosts.userId, gigiUsers.id))
    .where(and(...conditions))
    .orderBy(desc(gigiPosts.id))
    .limit(options.limit + 1);

  const hasMore = rows.length > options.limit;
  const items = rows.slice(0, options.limit).map(row => ({
    id: row.id,
    userId: row.userId,
    caption: row.caption,
    imageUrl: row.imageUrl,
    createdAt: row.createdAt,
    author: { username: row.authorUsername, avatarUrl: row.authorAvatarUrl },
    likeCount: Number(row.likeCount),
    commentCount: Number(row.commentCount),
    likedByMe: Boolean(row.likedByMe),
  }));
  return { items, nextCursor: hasMore && items.length ? items[items.length - 1]!.id : null };
}

export const appRouter = router({
  auth: router({
    me: publicProcedure.query(({ ctx }) => ctx.user),
    register: publicProcedure.input(credentials).mutation(async ({ ctx, input }) => {
      const wait = allowRegister(getIp(ctx.req));
      enforceRateLimit(wait, "Too many account creation attempts.");
      const db = await requireDatabase();
      const existing = await db.select({ id: gigiUsers.id }).from(gigiUsers).where(eq(gigiUsers.username, input.username)).limit(1);
      if (existing.length) throw new TRPCError({ code: "CONFLICT", message: "That username is already taken." });
      const passwordHash = await hashPassword(input.password);
      let userId: number;
      try {
        const inserted = await db.insert(gigiUsers).values({ username: input.username, passwordHash });
        userId = Number(inserted[0].insertId);
      } catch (error) {
        if ((error as { code?: string })?.code === "ER_DUP_ENTRY") throw new TRPCError({ code: "CONFLICT", message: "That username is already taken." });
        throw error;
      }
      await createAccountSession(userId, ctx.req, ctx.res);
      const [account] = await db.select(accountFields).from(gigiUsers).where(eq(gigiUsers.id, userId)).limit(1);
      return account ?? null;
    }),
    login: publicProcedure.input(credentials).mutation(async ({ ctx, input }) => {
      const wait = allowLogin(`${getIp(ctx.req)}:${input.username}`);
      enforceRateLimit(wait, "Too many sign-in attempts.");
      const db = await requireDatabase();
      const [account] = await db.select().from(gigiUsers).where(eq(gigiUsers.username, input.username)).limit(1);
      if (!account || !(await verifyPassword(input.password, account.passwordHash))) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "That username and password did not match." });
      }
      await createAccountSession(account.id, ctx.req, ctx.res);
      return { id: account.id, username: account.username, avatarUrl: account.avatarUrl, bio: account.bio, createdAt: account.createdAt };
    }),
    logout: publicProcedure.mutation(async ({ ctx }) => {
      await import("./auth").then(({ clearAccountSession }) => clearAccountSession(ctx.req, ctx.res));
      return { success: true as const };
    }),
  }),

  feed: router({
    list: publicProcedure
      .input(z.object({ limit: z.number().int().min(1).max(24).default(12), cursor: z.number().int().positive().optional() }).default({ limit: 12 }))
      .query(({ ctx, input }) => loadPostRows({ limit: input.limit, cursor: input.cursor, userId: ctx.user?.id })),
    get: publicProcedure.input(z.object({ id: z.number().int().positive() })).query(async ({ ctx, input }) => {
      const db = await requireDatabase();
      const [row] = await db.select({ id: gigiPosts.id }).from(gigiPosts).where(and(eq(gigiPosts.id, input.id), isNull(gigiPosts.deletedAt))).limit(1);
      if (!row) throw new TRPCError({ code: "NOT_FOUND", message: "This meme could not be found." });
      const page = await loadPostRows({ limit: 1, cursor: input.id + 1, userId: ctx.user?.id });
      const post = page.items.find(item => item.id === input.id);
      if (!post) {
        const directRows = await db.select({
          id: gigiPosts.id,
          userId: gigiPosts.userId,
          caption: gigiPosts.caption,
          imageUrl: gigiPosts.imageUrl,
          createdAt: gigiPosts.createdAt,
          authorUsername: gigiUsers.username,
          authorAvatarUrl: gigiUsers.avatarUrl,
          likeCount: sql<number>`(SELECT COUNT(*) FROM gigi_likes AS likes WHERE likes.postId = ${gigiPosts.id})`,
          commentCount: sql<number>`(SELECT COUNT(*) FROM gigi_comments AS comments WHERE comments.postId = ${gigiPosts.id} AND comments.deletedAt IS NULL)`,
          likedByMe: ctx.user ? sql<number>`EXISTS (SELECT 1 FROM gigi_likes AS mine WHERE mine.postId = ${gigiPosts.id} AND mine.userId = ${ctx.user.id})` : sql<number>`0`,
        }).from(gigiPosts).innerJoin(gigiUsers, eq(gigiPosts.userId, gigiUsers.id)).where(and(eq(gigiPosts.id, input.id), isNull(gigiPosts.deletedAt))).limit(1);
        const direct = directRows[0];
        if (!direct) throw new TRPCError({ code: "NOT_FOUND", message: "This meme could not be found." });
        return { id: direct.id, userId: direct.userId, caption: direct.caption, imageUrl: direct.imageUrl, createdAt: direct.createdAt, author: { username: direct.authorUsername, avatarUrl: direct.authorAvatarUrl }, likeCount: Number(direct.likeCount), commentCount: Number(direct.commentCount), likedByMe: Boolean(direct.likedByMe) };
      }
      return post;
    }),
  }),

  profile: router({
    get: publicProcedure.input(z.object({ username: USERNAME, cursor: z.number().int().positive().optional() })).query(async ({ input }) => {
      const db = await requireDatabase();
      const [profile] = await db.select(accountFields).from(gigiUsers).where(eq(gigiUsers.username, input.username)).limit(1);
      if (!profile) throw new TRPCError({ code: "NOT_FOUND", message: "This profile could not be found." });
      const [postCount] = await db.select({ value: count() }).from(gigiPosts).where(and(eq(gigiPosts.userId, profile.id), isNull(gigiPosts.deletedAt)));
      const posts = await loadPostRows({ limit: 24, cursor: input.cursor, authorId: profile.id });
      return { ...profile, postCount: Number(postCount?.value ?? 0), posts: posts.items, nextCursor: posts.nextCursor };
    }),
    update: protectedProcedure.input(z.object({ bio: z.string().trim().max(280), avatarUrl: z.string().max(512).optional() })).mutation(async ({ ctx, input }) => {
      if (input.avatarUrl && !imageBelongsToUser(input.avatarUrl, ctx.user.id, "profiles")) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Choose an image you uploaded for this profile." });
      }
      const db = await requireDatabase();
      await db.update(gigiUsers).set({ bio: input.bio, ...(input.avatarUrl ? { avatarUrl: input.avatarUrl } : {}) }).where(eq(gigiUsers.id, ctx.user.id));
      const [updated] = await db.select(accountFields).from(gigiUsers).where(eq(gigiUsers.id, ctx.user.id)).limit(1);
      return updated ?? null;
    }),
  }),

  posts: router({
    create: protectedProcedure.input(z.object({ caption: z.string().trim().max(500), imageUrl: z.string().min(1).max(512) })).mutation(async ({ ctx, input }) => {
      enforceRateLimit(allowPost(String(ctx.user.id)), "You have posted a lot recently.");
      if (!imageBelongsToUser(input.imageUrl, ctx.user.id, "posts")) throw new TRPCError({ code: "BAD_REQUEST", message: "Upload the meme image before publishing." });
      const db = await requireDatabase();
      const inserted = await db.insert(gigiPosts).values({ userId: ctx.user.id, caption: input.caption, imageUrl: input.imageUrl });
      return { id: Number(inserted[0].insertId) };
    }),
    delete: protectedProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      const db = await requireDatabase();
      const [post] = await db.select({ id: gigiPosts.id, userId: gigiPosts.userId }).from(gigiPosts).where(and(eq(gigiPosts.id, input.id), isNull(gigiPosts.deletedAt))).limit(1);
      if (!post) throw new TRPCError({ code: "NOT_FOUND", message: "This meme could not be found." });
      if (post.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN", message: "You can only remove your own memes." });
      await db.update(gigiPosts).set({ deletedAt: new Date() }).where(eq(gigiPosts.id, input.id));
      return { success: true as const };
    }),
  }),

  likes: router({
    toggle: protectedProcedure.input(z.object({ postId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      enforceRateLimit(allowLike(String(ctx.user.id)), "You are liking too quickly.");
      const db = await requireDatabase();
      const [post] = await db.select({ id: gigiPosts.id }).from(gigiPosts).where(and(eq(gigiPosts.id, input.postId), isNull(gigiPosts.deletedAt))).limit(1);
      if (!post) throw new TRPCError({ code: "NOT_FOUND", message: "This meme could not be found." });
      const [existing] = await db.select({ id: gigiLikes.id }).from(gigiLikes).where(and(eq(gigiLikes.userId, ctx.user.id), eq(gigiLikes.postId, input.postId))).limit(1);
      if (existing) {
        await db.delete(gigiLikes).where(eq(gigiLikes.id, existing.id));
        return { liked: false };
      }
      try {
        await db.insert(gigiLikes).values({ userId: ctx.user.id, postId: input.postId });
      } catch (error) {
        if ((error as { code?: string })?.code !== "ER_DUP_ENTRY") throw error;
      }
      return { liked: true };
    }),
  }),

  comments: router({
    list: publicProcedure.input(z.object({ postId: z.number().int().positive() })).query(async ({ input }) => {
      const db = await requireDatabase();
      return db.select({
        id: gigiComments.id,
        userId: gigiComments.userId,
        postId: gigiComments.postId,
        content: gigiComments.content,
        createdAt: gigiComments.createdAt,
        author: { username: gigiUsers.username, avatarUrl: gigiUsers.avatarUrl },
      }).from(gigiComments)
        .innerJoin(gigiUsers, eq(gigiComments.userId, gigiUsers.id))
        .where(and(eq(gigiComments.postId, input.postId), isNull(gigiComments.deletedAt)))
        .orderBy(desc(gigiComments.id))
        .limit(50);
    }),
    add: protectedProcedure.input(z.object({ postId: z.number().int().positive(), content: z.string().trim().min(1).max(500) })).mutation(async ({ ctx, input }) => {
      enforceRateLimit(allowComment(String(ctx.user.id)), "You have commented a lot recently.");
      const db = await requireDatabase();
      const [post] = await db.select({ id: gigiPosts.id }).from(gigiPosts).where(and(eq(gigiPosts.id, input.postId), isNull(gigiPosts.deletedAt))).limit(1);
      if (!post) throw new TRPCError({ code: "NOT_FOUND", message: "This meme could not be found." });
      const inserted = await db.insert(gigiComments).values({ userId: ctx.user.id, postId: input.postId, content: input.content });
      return { id: Number(inserted[0].insertId) };
    }),
    delete: protectedProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      const db = await requireDatabase();
      const [comment] = await db.select({ id: gigiComments.id, userId: gigiComments.userId }).from(gigiComments).where(and(eq(gigiComments.id, input.id), isNull(gigiComments.deletedAt))).limit(1);
      if (!comment) throw new TRPCError({ code: "NOT_FOUND", message: "This comment could not be found." });
      if (comment.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN", message: "You can only remove your own comments." });
      await db.update(gigiComments).set({ deletedAt: new Date() }).where(eq(gigiComments.id, input.id));
      return { success: true as const };
    }),
  }),
});

export type AppRouter = typeof appRouter;
