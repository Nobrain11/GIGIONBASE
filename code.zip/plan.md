# GIGI official site + separate Feed — implementation plan

## Goal and scope

Transform the current feed-first experience into the requested official GIGI project site while preserving the existing real meme community product. The root route `/` becomes the main brand/story homepage. The current working public feed moves to `/feed`, retaining its pagination, database-backed post cards and interactions, username/password accounts, profiles, post creation, comments, likes and public post URLs. The visitor must see GIGI’s brand introduction before the feed.

GIGI is presented as a meme token on Base dedicated to Chihuahua Gigi Marie. The blanket remains part of the supplied dog imagery only; it is not the project narrative. The existing cosmic mountain asset is a background design language, not a space/travel story. Continue using the supplied dog photo for the logo and authentic hero imagery where it fits. Keep the working configured Manus-managed MySQL/object-storage services and current server APIs; this request needs no schema or infrastructure change.

## Implementation approach

1. **Route separation and shell.** Move the existing feed page implementation from `client/src/pages/Home.tsx` to a dedicated `Feed.tsx` page with the same API queries, real posts, loading/empty/error states, `PostCard` behavior and pagination. Replace `Home.tsx` with the official long-scrolling landing page. Register `/feed`; preserve `/about` as a backward-compatible narrative route that links/scrolls back to the homepage’s About section. Keep `/post/new`, `/profile/:username`, `/meme/:id` and `/404`. Update `client/public/manus-routes.json` to declare all current page routes.

2. **Contextual navigation.** Update `SiteShell.tsx` to present the six requested main-site links—HOME, ABOUT, TOKEN, COMMUNITY, ROADMAP and FEED. The first five navigate to root/section anchors on the long-scrolling site, including from inner routes. FEED opens `/feed`. In the separate Feed experience show GIGI, FEED, POST A MEME, PROFILE (or login when signed out) and BACK TO GIGI. Preserve responsive mobile menu/bottom actions and login/logout behavior.

3. **Marketing homepage.** Build a clear hero with the GIGI mark/photo, “THE CUTEST MEME ON BASE.”, the supplied two-sentence Gigi Marie narrative, and working EXPLORE GIGI (scrolls) and ENTER THE FEED (routes to `/feed`) calls to action. Follow with distinct anchor sections for ABOUT GIGI, `$GIGI ON BASE` token details, COMMUNITY, the four provided roadmap phases, and an EVERYONE MEMES preview before the footer. Token Copy Contract remains functional. Describe roadmap phases as development goals, not promises. Use real recent feed records for previews only; when the database has no posts, show a truthful empty/teaser state rather than invented activity.

4. **Verified-link handling.** No X, Telegram or other official social URLs are present in the brief or existing project. Do not fabricate destinations. Display FOLLOW ON X and JOIN THE COMMUNITY as clearly unavailable/unlinked actions with concise “official link not provided” guidance; ENTER THE FEED remains functional. Keep financial metrics and promises absent.

5. **Brand system.** Build on the existing generated cosmic mountain visual and approved blue/navy palette: stars, low-intensity blue/violet trails, atmospheric ridgelines, subtle gradients, occasional glass/translucent surfaces, white display typography and Base-blue highlights. Keep text-safe deep overlays and the real supplied Gigi photo as a focal subject. Extend the varied navy/blue surfaces through cards, roadmap, token and footer without making every panel a flat blue, making GIGI a space-exploration narrative, or weakening mobile text contrast. Retain DM Sans + Fraunces unless the existing project reveals a concrete reason to change; use restrained transitions and respect reduced-motion preferences.

6. **Metadata and delivery.** Update the document title, description, theme color and social-preview text to identify GIGI as a Base meme-token/community project rather than a blanket brand. Do not invent a public canonical URL or unverified social preview target. Keep feed, account and API logic unchanged apart from routes/share copy that should reference GIGI/the Feed rather than the old blanket-first name.

## Main project structure

- `client/src/App.tsx`: root, Feed, backward-compatible About, composer, profile, meme-detail and not-found route declarations.
- `client/src/pages/Home.tsx`: official landing page, long-scroll story sections and real-feed teaser.
- `client/src/pages/Feed.tsx`: relocated current public feed, pagination and post cards.
- `client/src/pages/About.tsx`: retained About/token permalink for compatibility.
- `client/src/components/gigi/SiteShell.tsx`: route-aware brand shell/navigation/footer while preserving auth state and dialog.
- `client/src/components/gigi/PostCard.tsx`: existing authentic database-backed meme card/interactions, reused by Feed and existing detail routes.
- `client/src/index.css`: shared navy/blue cosmic system, responsive section and navigation rules, reduced-motion support.
- `client/public/manus-routes.json`: synchronized page route manifest.
- `client/index.html`: site-wide GIGI title, description and theme metadata.
- Existing `server/routers.ts`, `server/auth.ts`, `server/db.ts`, `drizzle/schema.ts` and storage helpers remain the backend of record; no migration is planned.

## Design description

**Design movement:** Premium Base-native editorial web3 with cinematic cosmic landscape art and bright internet-culture energy—not a space-travel interface.

**Core principles:** GIGI-first identity; legible white-on-navy contrast; blue as a distinctive Base cue rather than a flat wash; real community content and verified claims only.

**Color philosophy:** Midnight blue and navy establish depth and let Gigi’s tan/cream photo feel warm; crisp white carries the story; electric Base blue and light blue draw attention to actions; restrained violet appears only in atmospheric light and transitions.

**Layout paradigm:** A branded, spacious, vertically paced story from hero to about, token, community, roadmap and meme preview, then an explicit transition into the separate feed. Use asymmetric editorial bands and a timeline rather than a dashboard grid.

**Signature elements:** Text-safe cosmic mountain hero; fine star/light-trail details; translucent blue-edged content cards and a roadmap path that hints at the long ride.

**Interaction philosophy:** Navigation names the content plainly; Explore scrolls, Enter Feed changes experience, Copy Contract confirms success, and unavailable community links are explained instead of faked.

**Animation:** Gentle reveal/hover/scroll movement and background drift at low amplitude; no continuous distracting motion; disable nonessential motion under `prefers-reduced-motion`.

**Typography system:** Keep DM Sans for readable interface/body copy and Fraunces for expressive display headlines; use large compact hero type and clear section labels.

**Brand essence:** The cheerful Chihuahua-backed Base meme project for internet-culture and crypto communities, with a real social Feed behind the story; personality: playful, confident, welcoming.

**Brand voice:** Short, energetic, transparent. Examples: “THE CUTEST MEME ON BASE.” and “The long ride starts with one meme.”

**Wordmark & logo:** The user-supplied Gigi photo as the mascot mark paired with a confident custom-spaced “GIGI” wordmark in the existing display face; never imply the blanket itself is the project.

**Signature brand color:** Electric Base blue `#0052FF`, balanced by midnight navy `#08101F` and bright-blue display accents.
